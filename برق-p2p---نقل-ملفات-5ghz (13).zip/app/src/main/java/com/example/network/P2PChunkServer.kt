package com.example.network

import android.content.ContentResolver
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import com.example.model.ChunkSizeOption
import com.example.model.ConnectionApprovalStatus
import com.example.model.DiscoveredPeerSession
import com.example.model.HotspotNetworkStatus
import com.example.model.IncomingConnectionRequest
import com.example.model.TransferFileItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.util.Collections
import java.util.Locale
import java.util.UUID

/**
 * High-Throughput Network-Agnostic P2P HTTP/1.1 Keep-Alive Chunk & Stream Server
 * and UDP Discovery Engine for "برق sher".
 *
 * Performance & Security Architecture:
 * - Real session lifecycle with Session ID, Pairing Code, Expiration (TTL), and explicit
 *   Sender Approval handshake (/api/session-info -> /api/request-connect -> /api/connect-status)
 *   issuing an authorization token required for /api/chunk and /api/stream when approval is enabled.
 * - Persistent HTTP/1.1 Keep-Alive connections (eliminating per-chunk/per-file TCP handshakes).
 * - TCP_NODELAY + 512 KB socket send/receive buffers.
 * - Bounded-memory streaming (64 KB reusable ring buffer per worker) directly from
 *   RandomAccessFile / FileChannel / ContentResolver to the socket output stream without
 *   allocating multi-megabyte byte arrays in RAM.
 * - Full support for whole-folder hierarchy metadata (relativePath, rootFolderName, isDirectory).
 */
class P2PChunkServer(
    private val context: Context,
    private val scope: CoroutineScope,
    private val sessionCodeProvider: () -> String,
    private val isSenderReadyProvider: () -> Boolean,
    private val chunkSizeProvider: () -> ChunkSizeOption,
    private val filesProvider: () -> List<TransferFileItem>,
    private val onChunkServed: (fileId: String, chunkIndex: Int, bytesCount: Int) -> Unit,
    private val onPeerDiscovered: (DiscoveredPeerSession) -> Unit = {},
    private val onReceiverVerifiedFile: (fileId: String, verified: Boolean) -> Unit = { _, _ -> },
    private val sessionIdProvider: () -> String = { "SES-DEFAULT" },
    private val sessionExpiresAtProvider: () -> Long = { Long.MAX_VALUE },
    private val requireReceiverApprovalProvider: () -> Boolean = { false },
    private val onIncomingConnectionRequest: (IncomingConnectionRequest) -> Unit = {}
) {
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private var udpListenerJob: Job? = null
    private var udpAnnounceJob: Job? = null
    private var udpSocket: DatagramSocket? = null

    @Volatile
    private var currentPendingRequest: IncomingConnectionRequest? = null

    @Volatile
    private var currentApprovalStatus: ConnectionApprovalStatus = ConnectionApprovalStatus.NONE

    @Volatile
    private var approvedAuthToken: String = ""

    var boundPort: Int = 8989
        private set

    @Synchronized
    fun approvePendingConnectionRequest(): String {
        val token = UUID.randomUUID().toString().replace("-", "")
        approvedAuthToken = token
        currentApprovalStatus = ConnectionApprovalStatus.APPROVED
        return token
    }

    @Synchronized
    fun rejectPendingConnectionRequest() {
        approvedAuthToken = ""
        currentApprovalStatus = ConnectionApprovalStatus.REJECTED
    }

    @Synchronized
    fun resetSessionHandshake() {
        currentPendingRequest = null
        currentApprovalStatus = ConnectionApprovalStatus.NONE
        approvedAuthToken = ""
    }

    fun getApprovedAuthToken(): String = approvedAuthToken

    fun startServer(preferredPort: Int = 8989): Int {
        if (serverJob?.isActive == true && serverSocket?.isClosed == false) return boundPort
        val portsToTry = if (preferredPort == 0) {
            listOf(0)
        } else {
            (preferredPort..(preferredPort + 15)).toList() + listOf(0)
        }
        for (candidatePort in portsToTry) {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = candidatePort != 0
                try {
                    ss.receiveBufferSize = SOCKET_BUFFER_BYTES
                } catch (_: Exception) {
                }
                ss.bind(InetSocketAddress("0.0.0.0", candidatePort), 128)
                serverSocket = ss
                boundPort = ss.localPort
                break
            } catch (_: Exception) {
                // try next candidate port
            }
        }
        val activeSocket = serverSocket ?: return boundPort
        serverJob = scope.launch(Dispatchers.IO) {
            while (isActive && !activeSocket.isClosed) {
                try {
                    val client = activeSocket.accept()
                    launch(Dispatchers.IO) {
                        handleClient(client)
                    }
                } catch (_: Exception) {
                    if (!isActive) break
                }
            }
        }
        startUdpDiscoveryEngine()
        return boundPort
    }

    private fun startUdpDiscoveryEngine() {
        if (udpListenerJob?.isActive == true) return
        udpListenerJob = scope.launch(Dispatchers.IO) {
            try {
                val ds = DatagramSocket(null).apply {
                    reuseAddress = true
                    broadcast = true
                    bind(InetSocketAddress(UDP_DISCOVERY_PORT))
                }
                udpSocket = ds
                val buf = ByteArray(2048)
                while (isActive && !ds.isClosed) {
                    val packet = DatagramPacket(buf, buf.size)
                    ds.receive(packet)
                    val msg = String(packet.data, 0, packet.length, StandardCharsets.UTF_8).trim()
                    val senderIp = packet.address?.hostAddress ?: continue
                    handleUdpMessage(msg, senderIp)
                }
            } catch (_: Exception) {
            }
        }

        udpAnnounceJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                try {
                    val notExpired = System.currentTimeMillis() <= sessionExpiresAtProvider()
                    if (isSenderReadyProvider() && notExpired && filesProvider().isNotEmpty()) {
                        broadcastSenderPresence()
                    }
                } catch (_: Exception) {
                }
                delay(2000L)
            }
        }
    }

    private fun handleUdpMessage(msg: String, packetSenderIp: String) {
        if (msg.startsWith("BARQ_ANNOUNCE|")) {
            val parts = msg.split("|")
            if (parts.size >= 7) {
                val code = parts[1].trim()
                if (code.equals(sessionCodeProvider().trim(), ignoreCase = true) && isSenderReadyProvider()) {
                    return
                }
                val announcedIp = parts[2].trim().ifEmpty { packetSenderIp }
                val port = parts[3].toIntOrNull() ?: 8989
                val deviceName = parts[4].trim()
                val fileCount = parts[5].toIntOrNull() ?: 0
                val totalBytes = parts[6].toLongOrNull() ?: 0L
                onPeerDiscovered(
                    DiscoveredPeerSession(
                        sessionCode = code,
                        hostIp = if (announcedIp == "0.0.0.0" || announcedIp == "127.0.0.1") packetSenderIp else announcedIp,
                        port = port,
                        deviceName = deviceName,
                        fileCount = fileCount,
                        totalBytes = totalBytes,
                        lastSeenMillis = System.currentTimeMillis()
                    )
                )
            }
        } else if (msg.startsWith("BARQ_FIND|")) {
            val wantedCode = msg.substringAfter("BARQ_FIND|").trim()
            val notExpired = System.currentTimeMillis() <= sessionExpiresAtProvider()
            if (isSenderReadyProvider() && notExpired && filesProvider().isNotEmpty() &&
                wantedCode.equals(sessionCodeProvider().trim(), ignoreCase = true)
            ) {
                broadcastSenderPresence(targetIp = packetSenderIp)
            }
        }
    }

    fun broadcastSenderPresence(targetIp: String? = null) {
        val files = filesProvider()
        val notExpired = System.currentTimeMillis() <= sessionExpiresAtProvider()
        if (!isSenderReadyProvider() || !notExpired || files.isEmpty()) return
        val net = inspectNetworkStatus(context, boundPort, true)
        val deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}".trim().replace("|", " ")
        val totalBytes = files.sumOf { it.sizeBytes }
        val payload = "BARQ_ANNOUNCE|${sessionCodeProvider()}|${net.localIp}|$boundPort|$deviceModel|${files.size}|$totalBytes"
        val bytes = payload.toByteArray(StandardCharsets.UTF_8)

        try {
            DatagramSocket().use { senderSocket ->
                senderSocket.broadcast = true
                val targets = mutableSetOf<String>()
                if (!targetIp.isNullOrBlank()) {
                    targets.add(targetIp)
                } else {
                    targets.add("255.255.255.255")
                    net.allLocalIps.forEach { ip ->
                        val parts = ip.split(".")
                        if (parts.size == 4) {
                            targets.add("${parts[0]}.${parts[1]}.${parts[2]}.255")
                        }
                    }
                }
                for (dest in targets) {
                    try {
                        val addr = InetAddress.getByName(dest)
                        val pkt = DatagramPacket(bytes, bytes.size, addr, UDP_DISCOVERY_PORT)
                        senderSocket.send(pkt)
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    fun stopServer() {
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        try {
            udpSocket?.close()
        } catch (_: Exception) {
        }
        serverJob?.cancel()
        udpListenerJob?.cancel()
        udpAnnounceJob?.cancel()
    }

    /**
     * Handles a client socket with HTTP/1.1 Keep-Alive connection reuse and bounded 64 KB I/O buffers.
     */
    private fun handleClient(socket: Socket) {
        socket.use { client ->
            try {
                client.tcpNoDelay = true
                client.soTimeout = 30_000
                client.sendBufferSize = SOCKET_BUFFER_BYTES
                client.receiveBufferSize = SOCKET_BUFFER_BYTES
            } catch (_: Exception) {
            }

            val clientIp = client.inetAddress?.hostAddress ?: "127.0.0.1"
            val rawIn = BufferedInputStream(client.getInputStream(), STREAM_IO_BUFFER_BYTES)
            val out = BufferedOutputStream(client.getOutputStream(), SOCKET_OUTPUT_BUFFER_BYTES)
            val transferScratch = ByteArray(STREAM_IO_BUFFER_BYTES)

            while (!client.isClosed) {
                val requestLine = readHttpHeaderLine(rawIn) ?: break
                if (requestLine.isEmpty()) continue
                val parts = requestLine.split(" ")
                if (parts.size < 2) break
                val fullPath = parts[1]

                var clientWantsClose = false
                while (true) {
                    val headerLine = readHttpHeaderLine(rawIn) ?: break
                    if (headerLine.isEmpty()) break
                    if (headerLine.startsWith("Connection:", ignoreCase = true) &&
                        headerLine.contains("close", ignoreCase = true)
                    ) {
                        clientWantsClose = true
                    }
                }

                val keepAlive = !clientWantsClose
                val shouldContinue = dispatchHttpRequest(
                    fullPath = fullPath,
                    clientIp = clientIp,
                    out = out,
                    scratchBuffer = transferScratch,
                    keepAlive = keepAlive
                )
                if (!keepAlive || !shouldContinue) break
            }
        }
    }

    private fun readHttpHeaderLine(input: InputStream): String? {
        val sb = StringBuilder(128)
        while (true) {
            val b = input.read()
            if (b == -1) {
                return if (sb.isEmpty()) null else sb.toString()
            }
            if (b == '\n'.code) {
                val len = sb.length
                if (len > 0 && sb[len - 1] == '\r') {
                    sb.setLength(len - 1)
                }
                return sb.toString()
            }
            if (sb.length < 8192) {
                sb.append(b.toChar())
            }
        }
    }

    private fun isDownloadTokenAuthorized(providedToken: String): Boolean {
        if (!requireReceiverApprovalProvider()) return true
        return currentApprovalStatus == ConnectionApprovalStatus.APPROVED &&
            approvedAuthToken.isNotBlank() &&
            providedToken == approvedAuthToken
    }

    private fun dispatchHttpRequest(
        fullPath: String,
        clientIp: String,
        out: OutputStream,
        scratchBuffer: ByteArray,
        keepAlive: Boolean
    ): Boolean {
        return try {
            when {
                fullPath == "/" || fullPath.startsWith("/index") -> {
                    val net = inspectNetworkStatus(context, boundPort, true)
                    val htmlBytes = PeerJsWebPortalHtml.buildHtml(
                        defaultCode = sessionCodeProvider(),
                        hostIp = net.localIp,
                        hostPort = boundPort
                    ).toByteArray(StandardCharsets.UTF_8)
                    writeHttpHeader(out, "200 OK", "text/html; charset=utf-8", htmlBytes.size.toLong(), keepAlive)
                    out.write(htmlBytes)
                    out.flush()
                    true
                }

                fullPath.startsWith("/api/manifest") || fullPath.startsWith("/api/session-info") -> {
                    val query = fullPath.substringAfter("?", "")
                    val params = parseQueryParams(query)
                    val requestedCode = normalizeCode(params["code"] ?: "")
                    val activeCode = normalizeCode(sessionCodeProvider())
                    val files = filesProvider()
                    val senderReady = isSenderReadyProvider()
                    val expiresAt = sessionExpiresAtProvider()

                    if (senderReady && System.currentTimeMillis() > expiresAt) {
                        val expJson = JSONObject().apply {
                            put("error", "انتهت صلاحية جلسة الإرسال (Session Expired)، يرجى بدء جلسة جديدة من جهاز المرسل")
                            put("expired", true)
                        }.toString().toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "410 Gone", "application/json; charset=utf-8", expJson.size.toLong(), keepAlive)
                        out.write(expJson)
                        out.flush()
                        return true
                    }

                    if (!senderReady || files.isEmpty() || requestedCode.isEmpty() || requestedCode != activeCode) {
                        val errJson = JSONObject().apply {
                            put("error", "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد")
                        }.toString().toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "403 Forbidden", "application/json; charset=utf-8", errJson.size.toLong(), keepAlive)
                        out.write(errJson)
                        out.flush()
                        return true
                    }

                    val chunkBytes = chunkSizeProvider().bytes
                    val root = JSONObject()
                    root.put("sessionId", sessionIdProvider())
                    root.put("sessionCode", sessionCodeProvider().trim())
                    root.put("expiresAtMillis", expiresAt)
                    root.put("requiresApproval", requireReceiverApprovalProvider())
                    root.put("chunkSize", chunkBytes)
                    root.put("supportsStream", true)
                    root.put("supportsKeepAlive", true)
                    root.put("senderDevice", "${Build.MANUFACTURER} ${Build.MODEL}".trim())
                    root.put("fileCount", files.size)
                    root.put("totalBytes", files.sumOf { it.sizeBytes })
                    val arr = JSONArray()
                    for (f in files) {
                        val obj = JSONObject()
                        obj.put("id", f.id)
                        obj.put("name", f.name)
                        obj.put("sizeBytes", f.sizeBytes)
                        obj.put("category", f.category.name)
                        obj.put("totalChunks", maxOf(1, ((f.sizeBytes + chunkBytes - 1) / chunkBytes).toInt()))
                        obj.put("sha256", f.sha256Expected)
                        obj.put("hasSplitWarning", f.hasSplitWarning)
                        obj.put("relativePath", f.relativePath)
                        obj.put("rootFolderName", f.rootFolderName)
                        obj.put("folderBatchId", f.folderBatchId)
                        obj.put("isDirectory", f.isDirectory)
                        arr.put(obj)
                    }
                    root.put("files", arr)
                    val jsonBytes = root.toString().toByteArray(StandardCharsets.UTF_8)
                    writeHttpHeader(out, "200 OK", "application/json; charset=utf-8", jsonBytes.size.toLong(), keepAlive)
                    out.write(jsonBytes)
                    out.flush()
                    true
                }

                fullPath.startsWith("/api/request-connect") -> {
                    val query = fullPath.substringAfter("?", "")
                    val params = parseQueryParams(query)
                    val requestedCode = normalizeCode(params["code"] ?: "")
                    val activeCode = normalizeCode(sessionCodeProvider())
                    val files = filesProvider()
                    val senderReady = isSenderReadyProvider()
                    val expiresAt = sessionExpiresAtProvider()

                    if (senderReady && System.currentTimeMillis() > expiresAt) {
                        val expBytes = JSONObject().apply {
                            put("status", "EXPIRED")
                            put("error", "انتهت صلاحية جلسة الإرسال")
                        }.toString().toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "410 Gone", "application/json; charset=utf-8", expBytes.size.toLong(), keepAlive)
                        out.write(expBytes)
                        out.flush()
                        return true
                    }

                    if (!senderReady || files.isEmpty() || requestedCode.isEmpty() || requestedCode != activeCode) {
                        val errBytes = JSONObject().apply {
                            put("status", "DENIED")
                            put("error", "الجلسة غير نشطة أو كود الاتصال غير صحيح")
                        }.toString().toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "403 Forbidden", "application/json; charset=utf-8", errBytes.size.toLong(), keepAlive)
                        out.write(errBytes)
                        out.flush()
                        return true
                    }

                    val clientId = params["clientId"]?.ifBlank { UUID.randomUUID().toString().take(8) }
                        ?: UUID.randomUUID().toString().take(8)
                    val receiverName = params["deviceName"]?.ifBlank { "هاتف Android مستلم" }
                        ?: "هاتف Android مستلم"

                    val incomingReq = IncomingConnectionRequest(
                        requestId = clientId,
                        receiverDeviceName = receiverName,
                        receiverIp = clientIp,
                        requestedAtMillis = System.currentTimeMillis(),
                        fileCount = files.size,
                        totalBytes = files.sumOf { it.sizeBytes }
                    )

                    if (!requireReceiverApprovalProvider()) {
                        val token = approvePendingConnectionRequest()
                        val respBytes = JSONObject().apply {
                            put("status", "APPROVED")
                            put("requestId", clientId)
                            put("authToken", token)
                        }.toString().toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "200 OK", "application/json; charset=utf-8", respBytes.size.toLong(), keepAlive)
                        out.write(respBytes)
                        out.flush()
                        return true
                    }

                    synchronized(this) {
                        currentPendingRequest = incomingReq
                        currentApprovalStatus = ConnectionApprovalStatus.PENDING
                        approvedAuthToken = ""
                    }
                    onIncomingConnectionRequest(incomingReq)

                    val respBytes = JSONObject().apply {
                        put("status", "PENDING")
                        put("requestId", clientId)
                        put("message", "تم إرسال طلب الاتصال إلى المرسل، بانتظار الموافقة...")
                    }.toString().toByteArray(StandardCharsets.UTF_8)
                    writeHttpHeader(out, "200 OK", "application/json; charset=utf-8", respBytes.size.toLong(), keepAlive)
                    out.write(respBytes)
                    out.flush()
                    true
                }

                fullPath.startsWith("/api/connect-status") -> {
                    val query = fullPath.substringAfter("?", "")
                    val params = parseQueryParams(query)
                    val requestedCode = normalizeCode(params["code"] ?: "")
                    val activeCode = normalizeCode(sessionCodeProvider())
                    val senderReady = isSenderReadyProvider()
                    val expiresAt = sessionExpiresAtProvider()

                    if (!senderReady || requestedCode.isEmpty() || requestedCode != activeCode) {
                        val errBytes = JSONObject().apply {
                            put("status", "CANCELLED")
                            put("error", "تم إيقاف جلسة الإرسال من الطرف المرسل")
                        }.toString().toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "403 Forbidden", "application/json; charset=utf-8", errBytes.size.toLong(), keepAlive)
                        out.write(errBytes)
                        out.flush()
                        return true
                    }

                    if (System.currentTimeMillis() > expiresAt) {
                        val expBytes = JSONObject().apply {
                            put("status", "EXPIRED")
                            put("error", "انتهت صلاحية جلسة الإرسال")
                        }.toString().toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "410 Gone", "application/json; charset=utf-8", expBytes.size.toLong(), keepAlive)
                        out.write(expBytes)
                        out.flush()
                        return true
                    }

                    val respJson = JSONObject()
                    when {
                        !requireReceiverApprovalProvider() -> {
                            val token = if (approvedAuthToken.isNotBlank()) approvedAuthToken else approvePendingConnectionRequest()
                            respJson.put("status", "APPROVED")
                            respJson.put("authToken", token)
                        }
                        currentApprovalStatus == ConnectionApprovalStatus.APPROVED -> {
                            respJson.put("status", "APPROVED")
                            respJson.put("authToken", approvedAuthToken)
                        }
                        currentApprovalStatus == ConnectionApprovalStatus.REJECTED -> {
                            respJson.put("status", "REJECTED")
                            respJson.put("error", "رفض جهاز المرسل طلب الاتصال")
                        }
                        else -> {
                            respJson.put("status", "PENDING")
                        }
                    }
                    val respBytes = respJson.toString().toByteArray(StandardCharsets.UTF_8)
                    writeHttpHeader(out, "200 OK", "application/json; charset=utf-8", respBytes.size.toLong(), keepAlive)
                    out.write(respBytes)
                    out.flush()
                    true
                }

                fullPath.startsWith("/api/chunk") -> {
                    val query = fullPath.substringAfter("?", "")
                    val params = parseQueryParams(query)
                    val requestedCode = normalizeCode(params["code"] ?: "")
                    val activeCode = normalizeCode(sessionCodeProvider())
                    val senderReady = isSenderReadyProvider()
                    val providedToken = params["token"] ?: ""

                    if (!senderReady || requestedCode.isEmpty() || requestedCode != activeCode ||
                        System.currentTimeMillis() > sessionExpiresAtProvider() ||
                        !isDownloadTokenAuthorized(providedToken)
                    ) {
                        val err = "Forbidden: Invalid code, expired session, or receiver not approved by sender".toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "403 Forbidden", "text/plain; charset=utf-8", err.size.toLong(), keepAlive)
                        out.write(err)
                        out.flush()
                        return true
                    }

                    val fileId = params["fileId"] ?: params["id"] ?: ""
                    val chunkIndex = params["chunkIndex"]?.toIntOrNull() ?: params["index"]?.toIntOrNull() ?: -1
                    val customChunkSize = params["chunkSize"]?.toIntOrNull()
                    val fileItem = filesProvider().find { it.id == fileId }
                    if (fileItem == null || chunkIndex < 0) {
                        val err = "File or chunk index not found".toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "404 Not Found", "text/plain; charset=utf-8", err.size.toLong(), keepAlive)
                        out.write(err)
                        out.flush()
                        return true
                    }

                    if (fileItem.isDirectory || fileItem.sizeBytes == 0L) {
                        writeHttpHeader(out, "200 OK", "application/octet-stream", 0L, keepAlive)
                        out.flush()
                        onChunkServed(fileItem.id, 0, 0)
                        return true
                    }

                    val chunkSize = if (customChunkSize != null && customChunkSize in (16 * 1024)..(16 * 1024 * 1024)) {
                        customChunkSize
                    } else {
                        chunkSizeProvider().bytes
                    }
                    val offset = chunkIndex.toLong() * chunkSize.toLong()
                    val remaining = (fileItem.sizeBytes - offset).coerceAtLeast(0L)
                    val bytesToRead = minOf(chunkSize.toLong(), remaining)

                    val streamedOk = streamFileSliceToSocket(
                        resolver = context.contentResolver,
                        item = fileItem,
                        offset = offset,
                        length = bytesToRead,
                        out = out,
                        scratch = scratchBuffer,
                        keepAlive = keepAlive
                    )
                    if (!streamedOk) {
                        return false
                    }
                    onChunkServed(fileItem.id, chunkIndex, bytesToRead.toInt())
                    true
                }

                fullPath.startsWith("/api/stream") -> {
                    // High-speed continuous file range stream over Keep-Alive socket
                    val query = fullPath.substringAfter("?", "")
                    val params = parseQueryParams(query)
                    val requestedCode = normalizeCode(params["code"] ?: "")
                    val activeCode = normalizeCode(sessionCodeProvider())
                    val senderReady = isSenderReadyProvider()
                    val providedToken = params["token"] ?: ""

                    if (!senderReady || requestedCode.isEmpty() || requestedCode != activeCode ||
                        System.currentTimeMillis() > sessionExpiresAtProvider() ||
                        !isDownloadTokenAuthorized(providedToken)
                    ) {
                        val err = "Forbidden: Invalid code, expired session, or receiver not approved by sender".toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "403 Forbidden", "text/plain; charset=utf-8", err.size.toLong(), keepAlive)
                        out.write(err)
                        out.flush()
                        return true
                    }

                    val fileId = params["fileId"] ?: params["id"] ?: ""
                    val offset = (params["offset"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)
                    val chunkBytes = (params["chunkSize"]?.toIntOrNull() ?: chunkSizeProvider().bytes).coerceAtLeast(16 * 1024)
                    val fileItem = filesProvider().find { it.id == fileId }
                    if (fileItem == null) {
                        val err = "File not found".toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "404 Not Found", "text/plain; charset=utf-8", err.size.toLong(), keepAlive)
                        out.write(err)
                        out.flush()
                        return true
                    }

                    if (fileItem.isDirectory || fileItem.sizeBytes == 0L || offset >= fileItem.sizeBytes) {
                        writeHttpHeader(out, "200 OK", "application/octet-stream", 0L, keepAlive)
                        out.flush()
                        onChunkServed(fileItem.id, 0, 0)
                        return true
                    }

                    val remaining = fileItem.sizeBytes - offset
                    val startChunkIdx = (offset / chunkBytes).toInt()
                    val streamedOk = streamFileSliceToSocket(
                        resolver = context.contentResolver,
                        item = fileItem,
                        offset = offset,
                        length = remaining,
                        out = out,
                        scratch = scratchBuffer,
                        keepAlive = keepAlive,
                        reportProgressChunkBytes = chunkBytes,
                        startChunkIndex = startChunkIdx,
                        onProgressChunk = { cIdx, cBytes ->
                            onChunkServed(fileItem.id, cIdx, cBytes)
                        }
                    )
                    streamedOk
                }

                fullPath.startsWith("/api/ack") -> {
                    val query = fullPath.substringAfter("?", "")
                    val params = parseQueryParams(query)
                    val requestedCode = normalizeCode(params["code"] ?: "")
                    val activeCode = normalizeCode(sessionCodeProvider())
                    if (requestedCode.isNotEmpty() && requestedCode == activeCode) {
                        val fileId = params["fileId"] ?: ""
                        val verified = params["verified"] == "true"
                        val fileItem = filesProvider().find { it.id == fileId }
                        if (fileItem != null && (fileItem.isDirectory || fileItem.sizeBytes == 0L)) {
                            onChunkServed(fileId, 0, 0)
                        }
                        onReceiverVerifiedFile(fileId, verified)
                    }
                    val ok = "{\"status\":\"ok\"}".toByteArray(StandardCharsets.UTF_8)
                    writeHttpHeader(out, "200 OK", "application/json; charset=utf-8", ok.size.toLong(), keepAlive)
                    out.write(ok)
                    out.flush()
                    true
                }

                fullPath.startsWith("/barq-p2p.apk") || fullPath.startsWith("/download-apk") -> {
                    val apkFile = File(context.applicationInfo.sourceDir)
                    if (apkFile.exists()) {
                        val header = buildString {
                            append("HTTP/1.1 200 OK\r\n")
                            append("Content-Type: application/vnd.android.package-archive\r\n")
                            append("Content-Disposition: attachment; filename=\"Barq-Sher.apk\"\r\n")
                            append("Content-Length: ${apkFile.length()}\r\n")
                            append("Connection: close\r\n\r\n")
                        }
                        out.write(header.toByteArray(StandardCharsets.UTF_8))
                        FileInputStream(apkFile).use { fis ->
                            while (true) {
                                val r = fis.read(scratchBuffer)
                                if (r == -1) break
                                out.write(scratchBuffer, 0, r)
                            }
                        }
                        out.flush()
                    } else {
                        val err = "APK source not found".toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "404 Not Found", "text/plain", err.size.toLong(), false)
                        out.write(err)
                        out.flush()
                    }
                    false
                }

                else -> {
                    val msg = "Barq Sher P2P Endpoint".toByteArray(StandardCharsets.UTF_8)
                    writeHttpHeader(out, "404 Not Found", "text/plain", msg.size.toLong(), keepAlive)
                    out.write(msg)
                    out.flush()
                    true
                }
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Streamsatus-verified [length] bytes starting at [offset] directly to [out] using the bounded
     * 256 KB [scratch] buffer without allocating a full-chunk ByteArray in memory.
     *
     * CRITICAL CRASH & CORRUPTION PREVENTION:
     * Never writes the HTTP 200 header until the underlying file/URI stream is opened, positioned
     * at [offset], and verified readable. If a ContentProvider's ParcelFileDescriptor does not
     * support random-access seeking (e.g., pipe/virtual SAF document), cleanly falls back to
     * ContentResolver.openInputStream BEFORE any HTTP header bytes are sent on the socket.
     */
    private fun streamFileSliceToSocket(
        resolver: ContentResolver,
        item: TransferFileItem,
        offset: Long,
        length: Long,
        out: OutputStream,
        scratch: ByteArray,
        keepAlive: Boolean,
        reportProgressChunkBytes: Int = 0,
        startChunkIndex: Int = 0,
        onProgressChunk: ((chunkIdx: Int, bytesInChunk: Int) -> Unit)? = null
    ): Boolean {
        if (length <= 0L) {
            return try {
                writeHttpHeader(out, "200 OK", "application/octet-stream", 0L, keepAlive)
                out.flush()
                true
            } catch (e: Throwable) {
                android.util.Log.w(LOG_TAG, "Failed writing 0-length header for ${item.id}: ${e.message}")
                false
            }
        }

        val localFile = item.localFile
        if (localFile != null && localFile.exists() && localFile.isFile && localFile.canRead()) {
            var headerSent = false
            try {
                RandomAccessFile(localFile, "r").use { raf ->
                    val fileLen = raf.length()
                    if (offset > fileLen) return false
                    raf.seek(offset)
                    val firstToRead = minOf(scratch.size.toLong(), length).toInt()
                    val firstRead = raf.read(scratch, 0, firstToRead)
                    if (firstRead <= 0) return false

                    writeHttpHeader(out, "200 OK", "application/octet-stream", length, keepAlive)
                    headerSent = true
                    out.write(scratch, 0, firstRead)

                    var remaining = length - firstRead
                    var currentChunkIndex = startChunkIndex
                    var accruedInChunk = firstRead
                    if (reportProgressChunkBytes > 0 && onProgressChunk != null) {
                        while (accruedInChunk >= reportProgressChunkBytes) {
                            onProgressChunk(currentChunkIndex, reportProgressChunkBytes)
                            currentChunkIndex++
                            accruedInChunk -= reportProgressChunkBytes
                        }
                    }

                    while (remaining > 0L) {
                        val toRead = minOf(scratch.size.toLong(), remaining).toInt()
                        val readCount = raf.read(scratch, 0, toRead)
                        if (readCount <= 0) break
                        out.write(scratch, 0, readCount)
                        remaining -= readCount
                        if (reportProgressChunkBytes > 0 && onProgressChunk != null) {
                            accruedInChunk += readCount
                            while (accruedInChunk >= reportProgressChunkBytes) {
                                onProgressChunk(currentChunkIndex, reportProgressChunkBytes)
                                currentChunkIndex++
                                accruedInChunk -= reportProgressChunkBytes
                            }
                        }
                    }
                    if (reportProgressChunkBytes > 0 && onProgressChunk != null && accruedInChunk > 0) {
                        onProgressChunk(currentChunkIndex, accruedInChunk)
                    }
                    out.flush()
                    return remaining == 0L
                }
            } catch (e: Throwable) {
                android.util.Log.w(LOG_TAG, "Local file stream error for ${item.id} (headerSent=$headerSent): ${e.message}")
                if (headerSent) return false
            }
        }

        val uri = item.uri ?: return false
        var headerSentOnChannel = false
        try {
            resolver.openFileDescriptor(uri, "r")?.use { pfd ->
                FileInputStream(pfd.fileDescriptor).use { fis ->
                    val channel = fis.channel
                    if (offset > 0L) {
                        channel.position(offset)
                    }
                    val byteBuffer = ByteBuffer.wrap(scratch)
                    val firstStep = minOf(scratch.size.toLong(), length).toInt()
                    byteBuffer.clear()
                    byteBuffer.limit(firstStep)
                    val firstRead = channel.read(byteBuffer)
                    if (firstRead > 0) {
                        writeHttpHeader(out, "200 OK", "application/octet-stream", length, keepAlive)
                        headerSentOnChannel = true
                        out.write(scratch, 0, firstRead)

                        var remaining = length - firstRead
                        var currentChunkIndex = startChunkIndex
                        var accruedInChunk = firstRead
                        if (reportProgressChunkBytes > 0 && onProgressChunk != null) {
                            while (accruedInChunk >= reportProgressChunkBytes) {
                                onProgressChunk(currentChunkIndex, reportProgressChunkBytes)
                                currentChunkIndex++
                                accruedInChunk -= reportProgressChunkBytes
                            }
                        }

                        while (remaining > 0L) {
                            byteBuffer.clear()
                            val maxStep = minOf(scratch.size.toLong(), remaining).toInt()
                            byteBuffer.limit(maxStep)
                            val readCount = channel.read(byteBuffer)
                            if (readCount <= 0) break
                            out.write(scratch, 0, readCount)
                            remaining -= readCount
                            if (reportProgressChunkBytes > 0 && onProgressChunk != null) {
                                accruedInChunk += readCount
                                while (accruedInChunk >= reportProgressChunkBytes) {
                                    onProgressChunk(currentChunkIndex, reportProgressChunkBytes)
                                    currentChunkIndex++
                                    accruedInChunk -= reportProgressChunkBytes
                                }
                            }
                        }
                        if (reportProgressChunkBytes > 0 && onProgressChunk != null && accruedInChunk > 0) {
                            onProgressChunk(currentChunkIndex, accruedInChunk)
                        }
                        out.flush()
                        return remaining == 0L
                    }
                }
            }
        } catch (e: Throwable) {
            android.util.Log.w(LOG_TAG, "Channel stream fallback for URI ($uri), headerSent=$headerSentOnChannel: ${e.message}")
            if (headerSentOnChannel) {
                return false
            }
        }

        // Safe fallback for non-seekable ContentProvider / SAF streams (only reached if headerSentOnChannel == false)
        return try {
            val input = resolver.openInputStream(uri) ?: return false
            input.use { stream ->
                var remainingToSkip = offset
                while (remainingToSkip > 0L) {
                    val skipped = stream.skip(remainingToSkip)
                    if (skipped > 0L) {
                        remainingToSkip -= skipped
                    } else {
                        val toReadSkip = minOf(scratch.size.toLong(), remainingToSkip).toInt()
                        val readCount = stream.read(scratch, 0, toReadSkip)
                        if (readCount <= 0) return false
                        remainingToSkip -= readCount
                    }
                }
                val firstToRead = minOf(scratch.size.toLong(), length).toInt()
                val firstRead = stream.read(scratch, 0, firstToRead)
                if (firstRead <= 0) return false

                writeHttpHeader(out, "200 OK", "application/octet-stream", length, keepAlive)
                out.write(scratch, 0, firstRead)

                var remaining = length - firstRead
                var currentChunkIndex = startChunkIndex
                var accruedInChunk = firstRead
                if (reportProgressChunkBytes > 0 && onProgressChunk != null) {
                    while (accruedInChunk >= reportProgressChunkBytes) {
                        onProgressChunk(currentChunkIndex, reportProgressChunkBytes)
                        currentChunkIndex++
                        accruedInChunk -= reportProgressChunkBytes
                    }
                }

                while (remaining > 0L) {
                    val toRead = minOf(scratch.size.toLong(), remaining).toInt()
                    val readCount = stream.read(scratch, 0, toRead)
                    if (readCount <= 0) break
                    out.write(scratch, 0, readCount)
                    remaining -= readCount
                    if (reportProgressChunkBytes > 0 && onProgressChunk != null) {
                        accruedInChunk += readCount
                        while (accruedInChunk >= reportProgressChunkBytes) {
                            onProgressChunk(currentChunkIndex, reportProgressChunkBytes)
                            currentChunkIndex++
                            accruedInChunk -= reportProgressChunkBytes
                        }
                    }
                }
                if (reportProgressChunkBytes > 0 && onProgressChunk != null && accruedInChunk > 0) {
                    onProgressChunk(currentChunkIndex, accruedInChunk)
                }
                out.flush()
                remaining == 0L
            }
        } catch (e: Throwable) {
            android.util.Log.e(LOG_TAG, "Fallback InputStream error for ${item.id}: ${e.message}")
            false
        }
    }

    private fun writeHttpHeader(
        out: OutputStream,
        status: String,
        contentType: String,
        contentLength: Long,
        keepAlive: Boolean = true
    ) {
        val connValue = if (keepAlive) "keep-alive" else "close"
        val header = buildString(192) {
            append("HTTP/1.1 ").append(status).append("\r\n")
            append("Content-Type: ").append(contentType).append("\r\n")
            append("Content-Length: ").append(contentLength).append("\r\n")
            append("Access-Control-Allow-Origin: *\r\n")
            append("Cache-Control: no-store\r\n")
            if (keepAlive) {
                append("Keep-Alive: timeout=30, max=10000\r\n")
            }
            append("Connection: ").append(connValue).append("\r\n\r\n")
        }
        out.write(header.toByteArray(StandardCharsets.UTF_8))
    }

    private fun safeUrlDecode(raw: String): String {
        return try {
            URLDecoder.decode(raw, "UTF-8")
        } catch (_: Throwable) {
            raw
        }
    }

    private fun parseQueryParams(query: String): Map<String, String> {
        if (query.isBlank()) return emptyMap()
        return query.split("&").mapNotNull { pair ->
            val idx = pair.indexOf('=')
            if (idx <= 0) null
            else {
                val k = safeUrlDecode(pair.substring(0, idx))
                val v = safeUrlDecode(pair.substring(idx + 1))
                k to v
            }
        }.toMap()
    }

    companion object {
        private const val LOG_TAG = "BarqP2PServer"
        const val UDP_DISCOVERY_PORT = 8988
        const val SOCKET_BUFFER_BYTES = 4 * 1024 * 1024
        const val SOCKET_OUTPUT_BUFFER_BYTES = 1024 * 1024
        const val STREAM_IO_BUFFER_BYTES = 512 * 1024

        fun normalizeCode(raw: String): String {
            val trimmed = raw.trim().uppercase(Locale.US)
            if (trimmed.isEmpty()) return ""
            return trimmed.removePrefix("BRQ-").removePrefix("5G-")
        }

        /**
         * Reads the exact full chunk of [length] bytes at [offset] from the user-selected [TransferFileItem]
         * using ContentResolver or RandomAccessFile without loading the entire file into memory.
         */
        fun readFileChunk(
            resolver: ContentResolver,
            item: TransferFileItem,
            offset: Long,
            length: Int
        ): ByteArray? {
            if (length < 0) return null
            if (length == 0 || item.isDirectory || item.sizeBytes == 0L) return ByteArray(0)

            val localFile = item.localFile
            if (localFile != null && localFile.exists()) {
                return try {
                    RandomAccessFile(localFile, "r").use { raf ->
                        if (offset >= raf.length()) return ByteArray(0)
                        raf.seek(offset)
                        val maxReadable = minOf(length.toLong(), raf.length() - offset).toInt()
                        val buf = ByteArray(maxReadable)
                        var totalRead = 0
                        while (totalRead < maxReadable) {
                            val r = raf.read(buf, totalRead, maxReadable - totalRead)
                            if (r == -1) break
                            totalRead += r
                        }
                        if (totalRead == buf.size) buf else buf.copyOf(totalRead)
                    }
                } catch (_: IOException) {
                    null
                }
            }

            val uri = item.uri ?: return null
            try {
                resolver.openFileDescriptor(uri, "r")?.use { pfd ->
                    FileInputStream(pfd.fileDescriptor).use { fis ->
                        val channel = fis.channel
                        channel.position(offset)
                        val buf = ByteArray(length)
                        val byteBuffer = ByteBuffer.wrap(buf)
                        var totalRead = 0
                        while (totalRead < length) {
                            val r = channel.read(byteBuffer)
                            if (r <= 0) break
                            totalRead += r
                        }
                        if (totalRead > 0) {
                            return if (totalRead == length) buf else buf.copyOf(totalRead)
                        }
                    }
                }
            } catch (_: Exception) {
            }

            return try {
                val input = resolver.openInputStream(uri) ?: return null
                input.use { stream ->
                    var remainingToSkip = offset
                    val skipScratch = ByteArray(minOf(64 * 1024L, maxOf(1L, remainingToSkip)).toInt())
                    while (remainingToSkip > 0) {
                        val skipped = stream.skip(remainingToSkip)
                        if (skipped > 0) {
                            remainingToSkip -= skipped
                        } else {
                            val toReadSkip = minOf(skipScratch.size.toLong(), remainingToSkip).toInt()
                            val readCount = stream.read(skipScratch, 0, toReadSkip)
                            if (readCount == -1) return ByteArray(0)
                            remainingToSkip -= readCount
                        }
                    }

                    val out = ByteArrayOutputStream(minOf(length, 64 * 1024))
                    val readBuf = ByteArray(minOf(length, 64 * 1024))
                    var totalRead = 0
                    while (totalRead < length) {
                        val toRead = minOf(readBuf.size, length - totalRead)
                        val r = stream.read(readBuf, 0, toRead)
                        if (r == -1) break
                        out.write(readBuf, 0, r)
                        totalRead += r
                    }
                    if (totalRead == 0) null else out.toByteArray()
                }
            } catch (_: Exception) {
                null
            }
        }

        /**
         * Network-agnostic inspection of all active interfaces (Wi-Fi 2.4GHz, Wi-Fi 5GHz, Hotspot,
         * Ethernet, VPN, or Mobile 3G/4G/5G). Never restricts or rejects any network type.
         */
        fun inspectNetworkStatus(
            context: Context,
            port: Int,
            isServerRunning: Boolean
        ): HotspotNetworkStatus {
            val discoveredIps = mutableListOf<String>()
            var preferredIp = "127.0.0.1"
            var ifaceName = "شبكة محلية"

            try {
                val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
                for (ni in interfaces) {
                    if (!ni.isUp || ni.isLoopback) continue
                    val name = ni.name?.lowercase() ?: ""
                    val addrs = Collections.list(ni.inetAddresses)
                    for (addr in addrs) {
                        if (addr is Inet4Address && !addr.isLoopbackAddress) {
                            val ip = addr.hostAddress ?: continue
                            discoveredIps.add(ip)
                            val isWifiOrHotspot = name.contains("wlan") || name.contains("ap") ||
                                name.contains("swlan") || name.contains("rndis") || name.contains("eth")
                            if (preferredIp == "127.0.0.1" || isWifiOrHotspot || ip.startsWith("192.168.")) {
                                preferredIp = ip
                                ifaceName = ni.displayName ?: ni.name ?: "wlan0"
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            }

            if (discoveredIps.isEmpty()) {
                discoveredIps.add(preferredIp)
            }

            var freq = 0
            var linkSpeed = 0
            try {
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                @Suppress("DEPRECATION")
                val info = wm?.connectionInfo
                if (info != null) {
                    if (info.frequency > 0) freq = info.frequency
                    if (info.linkSpeed > 0) linkSpeed = info.linkSpeed
                }
            } catch (_: Exception) {
            }

            val is5G = freq >= 4900
            var netTypeLabel = when {
                freq >= 4900 -> "Wi-Fi (5GHz)"
                freq in 2400..2500 -> "Wi-Fi (2.4GHz)"
                preferredIp.startsWith("192.168.") || preferredIp.startsWith("172.") || preferredIp.startsWith("10.") ->
                    "شبكة محلية / نقطة اتصال متاحة"
                else -> "اتصال شبكة متاح"
            }

            try {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                val activeNet = cm?.activeNetwork
                val caps = if (activeNet != null) cm.getNetworkCapabilities(activeNet) else null
                if (caps != null) {
                    netTypeLabel = when {
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ->
                            if (is5G) "Wi-Fi (نطاق 5GHz)" else if (freq > 0) "Wi-Fi (نطاق 2.4GHz)" else "شبكة Wi-Fi متصلة"
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ->
                            "بيانات الجوال (3G / 4G / 5G) + نقطة اتصال"
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ->
                            "شبكة محلية (Ethernet)"
                        else -> netTypeLabel
                    }
                }
            } catch (_: Exception) {
            }

            return HotspotNetworkStatus(
                localIp = preferredIp,
                allLocalIps = discoveredIps.distinct(),
                port = port,
                is5GHzBand = is5G,
                frequencyMHz = freq,
                linkSpeedMbps = linkSpeed,
                ssidOrInterface = ifaceName,
                networkTypeLabel = netTypeLabel,
                isServerRunning = isServerRunning
            )
        }
    }
}
