package com.example.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.os.CancellationSignal
import android.util.Log
import android.util.LruCache
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.model.DeviceMediaItem
import com.example.model.FileCategory
import com.example.model.FolderBatchInfo
import com.example.model.PersistedSafFolderItem
import com.example.model.ReceivedApkItem
import com.example.model.StorageFolderItem
import com.example.model.TransferDirection
import com.example.model.TransferFileItem
import com.example.model.TransferHistoryRecord
import com.example.util.Sha256Util
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.RandomAccessFile
import java.net.URLDecoder
import java.util.Locale
import java.util.UUID
import kotlin.math.max

/**
 * Queries real device media and files via MediaStore, accessible storage directories,
 * and Storage Access Framework (SAF) DocumentTrees.
 *
 * Optimized for devices with thousands of photos and 40+ GB videos:
 * - Zero synchronous thumbnail extraction or blocking disk stats inside MediaStore cursor loops.
 * - Bounded in-memory LruCache (max 140 thumbnails, ~84x84 px) loaded lazily on demand for visible rows only.
 * - Never scans or reads full video content to list or preview videos.
 */
object DeviceMediaRepository {

    private const val LOG_TAG = "BarqMediaRepo"
    private const val THUMBNAIL_CACHE_MAX_ENTRIES = 140
    private const val THUMBNAIL_TARGET_PX = 84

    private val thumbnailCache = object : LruCache<String, ImageBitmap>(THUMBNAIL_CACHE_MAX_ENTRIES) {}
    private val thumbnailSemaphore = Semaphore(3)
    private val failedThumbnailIds = java.util.Collections.synchronizedSet(HashSet<String>())

    fun getCachedThumbnail(itemId: String): ImageBitmap? {
        return synchronized(thumbnailCache) {
            thumbnailCache.get(itemId)
        }
    }

    fun clearThumbnailCache() {
        synchronized(thumbnailCache) {
            thumbnailCache.evictAll()
        }
        failedThumbnailIds.clear()
    }

    /**
     * Lazily loads a small 84x84 thumbnail for a visible row on Dispatchers.IO, caching it in the
     * bounded LruCache. For large videos (up to 40+ GB), uses a strict timeout with CancellationSignal
     * so it never blocks or reads full video streams.
     */
    suspend fun getOrLoadThumbnailAsync(
        context: Context,
        item: DeviceMediaItem
    ): ImageBitmap? {
        item.thumbnailBitmap?.let { return it }
        getCachedThumbnail(item.id)?.let { return it }
        if (item.id in failedThumbnailIds) return null
        if (item.category != FileCategory.IMAGE && item.category != FileCategory.VIDEO) return null

        return withContext(Dispatchers.IO) {
            getCachedThumbnail(item.id)?.let { return@withContext it }
            thumbnailSemaphore.withPermit {
                getCachedThumbnail(item.id)?.let { return@withPermit it }
                val resolver = context.contentResolver
                val mediaId = item.id.substringAfterLast('_').toLongOrNull() ?: -1L
                val isVideo = item.category == FileCategory.VIDEO
                val loaded = if (isVideo) {
                    val signal = CancellationSignal()
                    try {
                        withTimeoutOrNull(600L) {
                            loadMediaThumbnailFast(
                                resolver = resolver,
                                uri = item.uri,
                                mediaId = mediaId,
                                isVideo = true,
                                fallbackFile = null,
                                cancellationSignal = signal
                            )
                        }
                    } finally {
                        runCatching { signal.cancel() }
                    }
                } else {
                    loadMediaThumbnailFast(
                        resolver = resolver,
                        uri = item.uri,
                        mediaId = mediaId,
                        isVideo = false,
                        fallbackFile = item.localFile,
                        cancellationSignal = null
                    )
                }

                if (loaded != null) {
                    synchronized(thumbnailCache) {
                        thumbnailCache.put(item.id, loaded)
                    }
                } else {
                    failedThumbnailIds.add(item.id)
                }
                loaded
            }
        }
    }

    fun loadImages(
        context: Context,
        maxItems: Int = 2500,
        offset: Int = 0
    ): List<DeviceMediaItem> {
        val resolver = context.contentResolver
        val items = ArrayList<DeviceMediaItem>(minOf(maxItems, 512))
        val seenPathsOrNames = HashSet<String>(minOf(maxItems, 512))
        val projection = buildList {
            add(MediaStore.Images.Media._ID)
            add(MediaStore.Images.Media.DISPLAY_NAME)
            add(MediaStore.Images.Media.SIZE)
            add(MediaStore.Images.Media.DATE_MODIFIED)
            add(MediaStore.Images.Media.MIME_TYPE)
            add(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.MediaColumns.RELATIVE_PATH)
            }
            @Suppress("DEPRECATION")
            add(MediaStore.MediaColumns.DATA)
        }.toTypedArray()
        val sortOrder = "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndex(MediaStore.Images.Media.SIZE)
                val dateCol = cursor.getColumnIndex(MediaStore.Images.Media.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndex(MediaStore.Images.Media.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                val relCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                } else -1
                @Suppress("DEPRECATION")
                val dataCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)

                if (offset > 0 && !cursor.moveToPosition(offset - 1)) {
                    return emptyList()
                }

                var count = 0
                while (cursor.moveToNext() && count < maxItems) {
                    val id = cursor.getLong(idCol)
                    val dataPath = if (dataCol >= 0) cursor.getString(dataCol) else null
                    val rawSize = if (sizeCol >= 0 && !cursor.isNull(sizeCol)) cursor.getLong(sizeCol) else 0L
                    // Avoid blocking File.exists() syscall inside cursor loop when MediaStore already knows rawSize > 0
                    val localFile = if (!dataPath.isNullOrBlank()) File(dataPath) else null
                    val name = (if (nameCol >= 0) cursor.getString(nameCol) else null)
                        ?: localFile?.name
                        ?: "IMG_$id.jpg"
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val size = when {
                        rawSize > 0L -> rawSize
                        count < 40 && localFile != null && localFile.exists() -> localFile.length()
                        count < 25 -> resolveContentUriLength(resolver, contentUri)
                        else -> 0L
                    }
                    if (rawSize <= 0L && size <= 0L && localFile != null && count < 40 && !localFile.exists()) continue

                    val dateSec = if (dateCol >= 0 && !cursor.isNull(dateCol)) cursor.getLong(dateCol) else 0L
                    val dateMillis = if (dateSec > 0L) dateSec * 1000L else System.currentTimeMillis()
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else "image/jpeg"
                    val relDirRaw = if (relCol >= 0) cursor.getString(relCol)?.trim('/') else null
                    val bucket = (if (bucketCol >= 0) cursor.getString(bucketCol) else null)
                        ?: relDirRaw
                        ?: localFile?.parentFile?.name
                        ?: "الصور"
                    val relPath = relDirRaw?.let { if (it.isNotBlank()) "$it/$name" else name } ?: name

                    val dedupKey = (dataPath ?: "$bucket/$name:$size").lowercase(Locale.ROOT)
                    if (!seenPathsOrNames.add(dedupKey)) continue

                    val itemId = "img_$id"
                    items.add(
                        DeviceMediaItem(
                            id = itemId,
                            name = name,
                            uri = contentUri,
                            localFile = localFile,
                            sizeBytes = size.coerceAtLeast(0L),
                            dateModifiedMillis = dateMillis,
                            mimeType = mime,
                            bucketOrFolderName = bucket,
                            relativePathInStorage = relPath,
                            category = FileCategory.IMAGE,
                            thumbnailBitmap = getCachedThumbnail(itemId)
                        )
                    )
                    count++
                }
            }
        } catch (se: SecurityException) {
            Log.w(LOG_TAG, "SecurityException in loadImages (permission not yet granted): ${se.message}")
        } catch (t: Throwable) {
            Log.e(LOG_TAG, "Error querying MediaStore.Images: ${t.message}", t)
        }

        // Only run lightweight fallback directory scan if MediaStore returned very few items (e.g., unindexed test files)
        if (offset == 0 && items.size < 30) {
            scanFallbackMediaDirectories(
                targetCategory = FileCategory.IMAGE,
                seenKeys = seenPathsOrNames,
                maxRemaining = minOf(100, maxItems - items.size),
                outList = items
            )
        }
        return items
    }

    fun loadVideos(
        context: Context,
        maxItems: Int = 1500,
        offset: Int = 0
    ): List<DeviceMediaItem> {
        val resolver = context.contentResolver
        val items = ArrayList<DeviceMediaItem>(minOf(maxItems, 256))
        val seenPathsOrNames = HashSet<String>(minOf(maxItems, 256))
        val projection = buildList {
            add(MediaStore.Video.Media._ID)
            add(MediaStore.Video.Media.DISPLAY_NAME)
            add(MediaStore.Video.Media.SIZE)
            add(MediaStore.Video.Media.DATE_MODIFIED)
            add(MediaStore.Video.Media.DURATION)
            add(MediaStore.Video.Media.MIME_TYPE)
            add(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.MediaColumns.RELATIVE_PATH)
            }
            @Suppress("DEPRECATION")
            add(MediaStore.MediaColumns.DATA)
        }.toTypedArray()
        val sortOrder = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndex(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndex(MediaStore.Video.Media.DATE_MODIFIED)
                val durCol = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                val mimeCol = cursor.getColumnIndex(MediaStore.Video.Media.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val relCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                } else -1
                @Suppress("DEPRECATION")
                val dataCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)

                if (offset > 0 && !cursor.moveToPosition(offset - 1)) {
                    return emptyList()
                }

                var count = 0
                while (cursor.moveToNext() && count < maxItems) {
                    val id = cursor.getLong(idCol)
                    val dataPath = if (dataCol >= 0) cursor.getString(dataCol) else null
                    val rawSize = if (sizeCol >= 0 && !cursor.isNull(sizeCol)) cursor.getLong(sizeCol) else 0L
                    // Never inspect or read multi-GB (up to 40 GB) video files during listing!
                    val localFile = if (!dataPath.isNullOrBlank()) File(dataPath) else null
                    val name = (if (nameCol >= 0) cursor.getString(nameCol) else null)
                        ?: localFile?.name
                        ?: "VID_$id.mp4"
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val size = when {
                        rawSize > 0L -> rawSize
                        count < 30 && localFile != null && localFile.exists() -> localFile.length()
                        count < 15 -> resolveContentUriLength(resolver, contentUri)
                        else -> 0L
                    }
                    if (rawSize <= 0L && size <= 0L && localFile != null && count < 30 && !localFile.exists()) continue

                    val dateSec = if (dateCol >= 0 && !cursor.isNull(dateCol)) cursor.getLong(dateCol) else 0L
                    val dateMillis = if (dateSec > 0L) dateSec * 1000L else System.currentTimeMillis()
                    val duration = if (durCol >= 0 && !cursor.isNull(durCol)) cursor.getLong(durCol) else 0L
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else "video/mp4"
                    val relDirRaw = if (relCol >= 0) cursor.getString(relCol)?.trim('/') else null
                    val bucket = (if (bucketCol >= 0) cursor.getString(bucketCol) else null)
                        ?: relDirRaw
                        ?: localFile?.parentFile?.name
                        ?: "الفيديوهات"
                    val relPath = relDirRaw?.let { if (it.isNotBlank()) "$it/$name" else name } ?: name

                    val dedupKey = (dataPath ?: "$bucket/$name:$size").lowercase(Locale.ROOT)
                    if (!seenPathsOrNames.add(dedupKey)) continue

                    val itemId = "vid_$id"
                    items.add(
                        DeviceMediaItem(
                            id = itemId,
                            name = name,
                            uri = contentUri,
                            localFile = localFile,
                            sizeBytes = size.coerceAtLeast(0L),
                            dateModifiedMillis = dateMillis,
                            durationMillis = duration,
                            mimeType = mime,
                            bucketOrFolderName = bucket,
                            relativePathInStorage = relPath,
                            category = FileCategory.VIDEO,
                            thumbnailBitmap = getCachedThumbnail(itemId)
                        )
                    )
                    count++
                }
            }
        } catch (se: SecurityException) {
            Log.w(LOG_TAG, "SecurityException in loadVideos (permission not yet granted): ${se.message}")
        } catch (t: Throwable) {
            Log.e(LOG_TAG, "Error querying MediaStore.Video: ${t.message}", t)
        }

        if (offset == 0 && items.size < 20) {
            scanFallbackMediaDirectories(
                targetCategory = FileCategory.VIDEO,
                seenKeys = seenPathsOrNames,
                maxRemaining = minOf(80, maxItems - items.size),
                outList = items
            )
        }
        return items
    }

    fun loadAudioFiles(
        context: Context,
        maxItems: Int = 1500,
        offset: Int = 0
    ): List<DeviceMediaItem> {
        val resolver = context.contentResolver
        val items = ArrayList<DeviceMediaItem>(minOf(maxItems, 256))
        val seenPathsOrNames = HashSet<String>(minOf(maxItems, 256))
        val projection = buildList {
            add(MediaStore.Audio.Media._ID)
            add(MediaStore.Audio.Media.DISPLAY_NAME)
            add(MediaStore.Audio.Media.TITLE)
            add(MediaStore.Audio.Media.SIZE)
            add(MediaStore.Audio.Media.DATE_MODIFIED)
            add(MediaStore.Audio.Media.DURATION)
            add(MediaStore.Audio.Media.MIME_TYPE)
            add(MediaStore.Audio.Media.ARTIST)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.MediaColumns.RELATIVE_PATH)
            }
            @Suppress("DEPRECATION")
            add(MediaStore.MediaColumns.DATA)
        }.toTypedArray()
        val sortOrder = "${MediaStore.Audio.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)
                val dateCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_MODIFIED)
                val durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                val mimeCol = cursor.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE)
                val artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                val relCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                } else -1
                @Suppress("DEPRECATION")
                val dataCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)

                if (offset > 0 && !cursor.moveToPosition(offset - 1)) {
                    return emptyList()
                }

                var count = 0
                while (cursor.moveToNext() && count < maxItems) {
                    val id = cursor.getLong(idCol)
                    val dataPath = if (dataCol >= 0) cursor.getString(dataCol) else null
                    val rawSize = if (sizeCol >= 0 && !cursor.isNull(sizeCol)) cursor.getLong(sizeCol) else 0L
                    val localFile = if (!dataPath.isNullOrBlank()) File(dataPath) else null
                    val displayName = (if (nameCol >= 0) cursor.getString(nameCol) else null)
                        ?: localFile?.name
                        ?: (if (titleCol >= 0) cursor.getString(titleCol) else null)
                        ?: "Audio_$id.mp3"
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val size = when {
                        rawSize > 0L -> rawSize
                        count < 30 && localFile != null && localFile.exists() -> localFile.length()
                        count < 15 -> resolveContentUriLength(resolver, contentUri)
                        else -> 0L
                    }
                    if (rawSize <= 0L && size <= 0L && localFile != null && count < 30 && !localFile.exists()) continue

                    val dateSec = if (dateCol >= 0 && !cursor.isNull(dateCol)) cursor.getLong(dateCol) else 0L
                    val dateMillis = if (dateSec > 0L) dateSec * 1000L else System.currentTimeMillis()
                    val duration = if (durCol >= 0 && !cursor.isNull(durCol)) cursor.getLong(durCol) else 0L
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else "audio/mpeg"
                    val artist = if (artistCol >= 0) cursor.getString(artistCol) ?: "" else ""
                    val relDirRaw = if (relCol >= 0) cursor.getString(relCol)?.trim('/') else null
                    val relPath = relDirRaw?.let { if (it.isNotBlank()) "$it/$displayName" else displayName }
                        ?: displayName

                    val dedupKey = (dataPath ?: "$artist/$displayName:$size").lowercase(Locale.ROOT)
                    if (!seenPathsOrNames.add(dedupKey)) continue

                    items.add(
                        DeviceMediaItem(
                            id = "aud_$id",
                            name = displayName,
                            uri = contentUri,
                            localFile = localFile,
                            sizeBytes = size.coerceAtLeast(0L),
                            dateModifiedMillis = dateMillis,
                            durationMillis = duration,
                            mimeType = mime,
                            bucketOrFolderName = artist.ifBlank { "الصوتيات" },
                            relativePathInStorage = relPath,
                            category = FileCategory.AUDIO
                        )
                    )
                    count++
                }
            }
        } catch (se: SecurityException) {
            Log.w(LOG_TAG, "SecurityException in loadAudioFiles: ${se.message}")
        } catch (t: Throwable) {
            Log.e(LOG_TAG, "Error querying MediaStore.Audio: ${t.message}", t)
        }

        if (offset == 0 && items.size < 20) {
            scanFallbackMediaDirectories(
                targetCategory = FileCategory.AUDIO,
                seenKeys = seenPathsOrNames,
                maxRemaining = minOf(80, maxItems - items.size),
                outList = items
            )
        }
        return items
    }

    private fun resolveContentUriLength(resolver: ContentResolver, uri: Uri): Long {
        return try {
            resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                if (afd.length > 0L) afd.length else 0L
            } ?: 0L
        } catch (_: Throwable) {
            0L
        }
    }

    private fun scanFallbackMediaDirectories(
        targetCategory: FileCategory,
        seenKeys: MutableSet<String>,
        maxRemaining: Int,
        outList: MutableList<DeviceMediaItem>
    ) {
        if (maxRemaining <= 0) return
        val candidateDirs = mutableListOf<File>()
        try {
            @Suppress("DEPRECATION")
            val dirs = when (targetCategory) {
                FileCategory.IMAGE -> listOfNotNull(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                )
                FileCategory.VIDEO -> listOfNotNull(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                )
                FileCategory.AUDIO -> listOfNotNull(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                )
                else -> listOfNotNull(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                )
            }
            candidateDirs.addAll(dirs)
        } catch (_: Throwable) {
        }

        val visitedCanonical = HashSet<String>()
        var added = 0
        var inspectedFiles = 0
        val maxInspectedFiles = 300

        fun walk(dir: File, depth: Int) {
            if (added >= maxRemaining || inspectedFiles >= maxInspectedFiles || depth > 3 || !dir.exists() || !dir.isDirectory || !dir.canRead()) return
            val canon = try {
                dir.canonicalPath
            } catch (_: Exception) {
                dir.absolutePath
            }
            if (!visitedCanonical.add(canon)) return
            val children = dir.listFiles() ?: return
            for (child in children) {
                if (added >= maxRemaining || inspectedFiles >= maxInspectedFiles) break
                if (child.name.startsWith(".")) continue
                if (child.isDirectory && child.canRead()) {
                    walk(child, depth + 1)
                } else if (child.isFile && child.canRead()) {
                    inspectedFiles++
                    val cat = FileCategory.fromFileName(child.name)
                    if (cat == targetCategory) {
                        val dedupKey = child.absolutePath.lowercase(Locale.ROOT)
                        if (seenKeys.add(dedupKey)) {
                            val itemId = "fb_${targetCategory.name}_${child.absolutePath.hashCode()}"
                            outList.add(
                                DeviceMediaItem(
                                    id = itemId,
                                    name = child.name,
                                    localFile = child,
                                    sizeBytes = child.length().coerceAtLeast(0L),
                                    dateModifiedMillis = child.lastModified(),
                                    bucketOrFolderName = dir.name,
                                    relativePathInStorage = "${dir.name}/${child.name}",
                                    category = targetCategory,
                                    thumbnailBitmap = getCachedThumbnail(itemId)
                                )
                            )
                            added++
                        }
                    }
                }
            }
        }

        for (root in candidateDirs.distinctBy { it.absolutePath }) {
            walk(root, 0)
        }
    }

    /**
     * Loads general files (Documents, PDFs, ZIP/RAR Archives, APKs, Downloads, Recent files)
     * from MediaStore.Files, MediaStore.Downloads (API 29+), and accessible storage directories.
     */
    private data class RecursiveDirStats(
        val fileCount: Int,
        val subfolderCount: Int,
        val emptySubfolderCount: Int,
        val totalBytes: Long
    )

    val STANDARD_ROOT_FOLDER_ORDER = listOf(
        "Download",
        "DCIM",
        "Pictures",
        "Movies",
        "Documents",
        "Music",
        "Android",
        "SDCard"
    )

    fun loadGeneralFilesAndFolders(
        context: Context,
        extraMediaItems: List<DeviceMediaItem> = emptyList()
    ): Pair<List<DeviceMediaItem>, List<StorageFolderItem>> {
        val resolver = context.contentResolver
        val seenKeys = HashSet<String>()
        val allFiles = mutableListOf<DeviceMediaItem>()
        val mediaStoreFolderGroups = LinkedHashMap<String, MutableList<DeviceMediaItem>>()

        @Suppress("DEPRECATION")
        val externalRootPath = try {
            Environment.getExternalStorageDirectory()?.absolutePath?.trimEnd('/') ?: "/storage/emulated/0"
        } catch (_: Exception) {
            "/storage/emulated/0"
        }

        fun recordMediaStoreFolderItem(relDirRaw: String, item: DeviceMediaItem) {
            val cleanRel = relDirRaw.trim().trim('/').replace('\\', '/')
            if (cleanRel.isBlank()) return
            val lower = cleanRel.lowercase(Locale.ROOT)
            if (lower.startsWith("android/data") || lower.startsWith("android/obb")) return
            val segments = cleanRel.split('/').filter { it.isNotBlank() }
            if (segments.isEmpty()) return
            // Register every level from root (e.g. "Download", "DCIM", "Android", "WhatsApp") down to the exact subfolder
            for (level in 1..segments.size) {
                val prefixPath = segments.subList(0, level).joinToString("/")
                val list = mediaStoreFolderGroups.getOrPut(prefixPath) { mutableListOf() }
                if (list.size < 2000) {
                    list.add(item)
                }
            }
        }

        // Merge preloaded Images, Videos, and Audio items so DCIM, Pictures, Movies, Music, etc. are indexed
        for (extra in extraMediaItems) {
            val relPath = extra.relativePathInStorage.trim().trim('/').ifBlank {
                when (extra.category) {
                    FileCategory.IMAGE -> "DCIM/${extra.name}"
                    FileCategory.VIDEO -> "Movies/${extra.name}"
                    FileCategory.AUDIO -> "Music/${extra.name}"
                    else -> "Download/${extra.name}"
                }
            }
            val relDir = relPath.substringBeforeLast('/', "").ifBlank {
                when (extra.category) {
                    FileCategory.IMAGE -> "DCIM"
                    FileCategory.VIDEO -> "Movies"
                    FileCategory.AUDIO -> "Music"
                    else -> "Download"
                }
            }
            val key = "${relPath.lowercase(Locale.ROOT)}:${extra.sizeBytes}"
            if (seenKeys.add(key)) {
                val normalizedItem = if (extra.relativePathInStorage.isNotBlank() && extra.relativePathInStorage.contains('/')) {
                    extra
                } else {
                    extra.copy(
                        bucketOrFolderName = relDir,
                        relativePathInStorage = "$relDir/${extra.name}"
                    )
                }
                allFiles.add(normalizedItem)
                recordMediaStoreFolderItem(relDir, normalizedItem)
            }
        }

        // 1. Query MediaStore.Downloads on API 29+ (including RELATIVE_PATH for subfolders like Download/ropon)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val dlProjection = arrayOf(
                MediaStore.Downloads._ID,
                MediaStore.Downloads.DISPLAY_NAME,
                MediaStore.Downloads.SIZE,
                MediaStore.Downloads.DATE_MODIFIED,
                MediaStore.Downloads.MIME_TYPE,
                MediaStore.MediaColumns.RELATIVE_PATH
            )
            try {
                resolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    dlProjection,
                    null,
                    null,
                    "${MediaStore.Downloads.DATE_MODIFIED} DESC"
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                    val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.SIZE)
                    val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DATE_MODIFIED)
                    val mimeCol = cursor.getColumnIndex(MediaStore.Downloads.MIME_TYPE)
                    val relCol = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)

                    var dlCount = 0
                    while (cursor.moveToNext() && dlCount < 2500) {
                        val id = cursor.getLong(idCol)
                        val name = cursor.getString(nameCol) ?: continue
                        val size = cursor.getLong(sizeCol).coerceAtLeast(0L)
                        val dateSec = cursor.getLong(dateCol)
                        val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                        val relDir = (if (relCol >= 0) cursor.getString(relCol) else null)
                            ?.trim()?.trim('/')?.ifBlank { "Download" } ?: "Download"
                        val uri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id)
                        val relFilePath = "$relDir/$name"
                        val key = "${relFilePath.lowercase(Locale.ROOT)}:$size"
                        if (seenKeys.add(key)) {
                            val mediaItem = DeviceMediaItem(
                                id = "dl_$id",
                                name = name,
                                uri = uri,
                                sizeBytes = size,
                                dateModifiedMillis = dateSec * 1000L,
                                mimeType = mime,
                                bucketOrFolderName = relDir,
                                relativePathInStorage = relFilePath,
                                category = FileCategory.fromFileName(name, mime)
                            )
                            allFiles.add(mediaItem)
                            recordMediaStoreFolderItem(relDir, mediaItem)
                            dlCount++
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }

        // 2. Query MediaStore.Files for Documents, Archives, APKs, Media, and files inside any subfolder or root
        val filesUri = MediaStore.Files.getContentUri("external")
        val fileProj = buildList {
            add(MediaStore.Files.FileColumns._ID)
            add(MediaStore.Files.FileColumns.DISPLAY_NAME)
            add(MediaStore.Files.FileColumns.SIZE)
            add(MediaStore.Files.FileColumns.DATE_MODIFIED)
            add(MediaStore.Files.FileColumns.MIME_TYPE)
            add(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.MediaColumns.RELATIVE_PATH)
            }
            @Suppress("DEPRECATION")
            add(MediaStore.MediaColumns.DATA)
        }.toTypedArray()

        try {
            resolver.query(
                filesUri,
                fileProj,
                "${MediaStore.Files.FileColumns.SIZE} > 0",
                null,
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                val relCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                } else -1
                @Suppress("DEPRECATION")
                val dataCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)

                var count = 0
                while (cursor.moveToNext() && count < 1800) {
                    val id = cursor.getLong(idCol)
                    val dataPath = if (dataCol >= 0) cursor.getString(dataCol) else null
                    val name = (if (nameCol >= 0) cursor.getString(nameCol) else null)
                        ?: dataPath?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
                        ?: continue
                    if (name.startsWith(".")) continue
                    val size = cursor.getLong(sizeCol).coerceAtLeast(0L)
                    val dateSec = cursor.getLong(dateCol)
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                    val bucket = if (bucketCol >= 0) cursor.getString(bucketCol) ?: "" else ""
                    val rawRel = (if (relCol >= 0) cursor.getString(relCol) else null)?.trim()?.trim('/')
                        ?: dataPath?.let { dp ->
                            if (dp.startsWith(externalRootPath)) {
                                dp.removePrefix(externalRootPath).trim('/').substringBeforeLast('/', "")
                            } else ""
                        }

                    val relDir = rawRel ?: bucket
                    val relFilePath = if (relDir.isNotBlank()) "$relDir/$name" else name
                    val key = "${relFilePath.lowercase(Locale.ROOT)}:$size"
                    if (seenKeys.add(key)) {
                        val contentUri = ContentUris.withAppendedId(filesUri, id)
                        val localF = dataPath?.let { File(it) }
                        val mediaItem = DeviceMediaItem(
                            id = "file_$id",
                            name = name,
                            uri = contentUri,
                            localFile = localF,
                            sizeBytes = size,
                            dateModifiedMillis = dateSec * 1000L,
                            mimeType = mime,
                            bucketOrFolderName = relDir,
                            relativePathInStorage = relFilePath,
                            category = FileCategory.fromFileName(name, mime)
                        )
                        allFiles.add(mediaItem)
                        if (relDir.isNotBlank()) {
                            recordMediaStoreFolderItem(relDir, mediaItem)
                        }
                        count++
                    }
                }
            }
        } catch (_: Exception) {
        }

        // 3. Dynamically read the real Internal Storage Root (/storage/emulated/0) + Public Directories + SD Card
        val rootDirMap = LinkedHashMap<String, File>()
        try {
            @Suppress("DEPRECATION")
            val extRoot = Environment.getExternalStorageDirectory()
            if (extRoot != null && extRoot.exists()) {
                // First, list all real directories and files at the root of shared internal storage
                if (extRoot.canRead()) {
                    extRoot.listFiles()?.forEach { topChild ->
                        if (topChild.name.startsWith(".")) return@forEach
                        if (topChild.isDirectory) {
                            rootDirMap[topChild.name] = topChild
                        } else if (topChild.isFile && topChild.canRead()) {
                            val len = topChild.length().coerceAtLeast(0L)
                            val key = "${topChild.name.lowercase(Locale.ROOT)}:$len"
                            if (seenKeys.add(key)) {
                                allFiles.add(
                                    DeviceMediaItem(
                                        id = "root_disk_${topChild.absolutePath.hashCode()}",
                                        name = topChild.name,
                                        localFile = topChild,
                                        sizeBytes = len,
                                        dateModifiedMillis = topChild.lastModified(),
                                        bucketOrFolderName = "",
                                        relativePathInStorage = topChild.name,
                                        category = FileCategory.fromFileName(topChild.name)
                                    )
                                )
                            }
                        }
                    }
                }
                // Ensure Android directory is registered if it exists on the device
                val androidDir = File(extRoot, "Android")
                if (androidDir.exists() && "Android" !in rootDirMap) {
                    rootDirMap["Android"] = androidDir
                }
            }
        } catch (_: Exception) {
        }

        // Also check standard Android public directories so they are discoverable even when Scoped Storage restricts extRoot.listFiles()
        try {
            @Suppress("DEPRECATION")
            val publicCandidates = listOf(
                "Download" to (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) ?: File(externalRootPath, "Download")),
                "DCIM" to (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) ?: File(externalRootPath, "DCIM")),
                "Pictures" to (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) ?: File(externalRootPath, "Pictures")),
                "Movies" to (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) ?: File(externalRootPath, "Movies")),
                "Documents" to (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) ?: File(externalRootPath, "Documents")),
                "Music" to (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC) ?: File(externalRootPath, "Music")),
                "Notifications" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_NOTIFICATIONS),
                "Ringtones" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_RINGTONES),
                "Alarms" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_ALARMS),
                "Podcasts" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PODCASTS),
                "Android" to File(externalRootPath, "Android")
            )
            val coreNames = setOf("Download", "DCIM", "Pictures", "Movies", "Documents", "Music", "Android")
            for ((label, pubDir) in publicCandidates) {
                if (pubDir != null && label !in rootDirMap) {
                    if (pubDir.exists() || label in coreNames || label in mediaStoreFolderGroups) {
                        rootDirMap[label] = pubDir
                    }
                }
            }
        } catch (_: Exception) {
        }

        // Detect Removable SD Card / Secondary Storage Volumes automatically without forcing SAF
        try {
            val externalDirs = context.getExternalFilesDirs(null)
            if (externalDirs != null && externalDirs.size > 1) {
                for (i in 1 until externalDirs.size) {
                    val extAppDir = externalDirs[i] ?: continue
                    val abs = extAppDir.absolutePath.replace('\\', '/')
                    val sdRootPath = abs.substringBefore("/Android/data", "").trimEnd('/')
                    if (sdRootPath.isNotBlank() && sdRootPath != externalRootPath) {
                        val sdRoot = File(sdRootPath)
                        if (sdRoot.exists() && sdRoot.isDirectory) {
                            rootDirMap["SDCard"] = sdRoot
                        } else if (extAppDir.exists() && extAppDir.isDirectory) {
                            rootDirMap["SDCard"] = extAppDir
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }

        val discoveredDirs = LinkedHashMap<String, Pair<String, File>>()
        val singlePassStatsMap = HashMap<String, RecursiveDirStats>()
        val visitedCollectCanon = HashSet<String>()
        var totalDiskFilesInspected = 0
        // Strict global cap across the entire call so startup never blocks even with 50,000 files on disk
        val maxDiskFilesToInspect = 300

        fun collectDirectoriesAndFiles(dir: File, relDisplayPath: String, depth: Int): RecursiveDirStats {
            val lowerPath = dir.absolutePath.lowercase(Locale.ROOT)
            val isProtected = lowerPath.endsWith("/android/data") ||
                lowerPath.endsWith("/android/obb") ||
                lowerPath.contains("/android/data/") ||
                lowerPath.contains("/android/obb/")
            if (isProtected) {
                discoveredDirs.putIfAbsent(dir.absolutePath, relDisplayPath to dir)
                val empty = RecursiveDirStats(0, 0, 0, 0L)
                singlePassStatsMap[dir.absolutePath] = empty
                return empty
            }
            if (depth > 3 || !dir.exists() || !dir.isDirectory) {
                return RecursiveDirStats(0, 0, 0, 0L)
            }
            discoveredDirs.putIfAbsent(dir.absolutePath, relDisplayPath to dir)
            if (!dir.canRead() || totalDiskFilesInspected >= maxDiskFilesToInspect) {
                val empty = RecursiveDirStats(0, 0, 0, 0L)
                singlePassStatsMap.putIfAbsent(dir.absolutePath, empty)
                return empty
            }
            val canon = try {
                dir.canonicalPath
            } catch (_: Exception) {
                dir.absolutePath
            }
            if (!visitedCollectCanon.add("$relDisplayPath|$canon")) {
                return singlePassStatsMap[dir.absolutePath] ?: RecursiveDirStats(0, 0, 0, 0L)
            }

            val children = dir.listFiles() ?: return RecursiveDirStats(0, 0, 0, 0L)
            var filesCount = 0
            var subfoldersCount = 0
            var emptySubfoldersCount = 0
            var bytesCount = 0L

            for (child in children) {
                if (child.name.startsWith(".")) continue
                val childRelPath = "$relDisplayPath/${child.name}"
                if (child.isDirectory) {
                    subfoldersCount++
                    discoveredDirs.putIfAbsent(child.absolutePath, childRelPath to child)
                    if (totalDiskFilesInspected < maxDiskFilesToInspect && depth < 3 && child.canRead()) {
                        val subStats = collectDirectoriesAndFiles(child, childRelPath, depth + 1)
                        filesCount += subStats.fileCount
                        subfoldersCount += subStats.subfolderCount
                        emptySubfoldersCount += subStats.emptySubfolderCount
                        bytesCount += subStats.totalBytes
                        if (subStats.fileCount == 0 && subStats.subfolderCount == 0) {
                            emptySubfoldersCount++
                        }
                    }
                } else if (child.isFile && child.canRead()) {
                    filesCount++
                    if (totalDiskFilesInspected < maxDiskFilesToInspect) {
                        totalDiskFilesInspected++
                        val len = child.length().coerceAtLeast(0L)
                        bytesCount += len
                        val key = "${childRelPath.lowercase(Locale.ROOT)}:$len"
                        if (seenKeys.add(key)) {
                            val item = DeviceMediaItem(
                                id = "disk_${child.absolutePath.hashCode()}",
                                name = child.name,
                                localFile = child,
                                sizeBytes = len,
                                dateModifiedMillis = child.lastModified(),
                                bucketOrFolderName = relDisplayPath,
                                relativePathInStorage = childRelPath,
                                category = FileCategory.fromFileName(child.name)
                            )
                            allFiles.add(item)
                            recordMediaStoreFolderItem(relDisplayPath, item)
                        }
                    }
                }
            }
            val stats = RecursiveDirStats(filesCount, subfoldersCount, emptySubfoldersCount, bytesCount)
            singlePassStatsMap[dir.absolutePath] = stats
            return stats
        }

        for ((label, rootDir) in rootDirMap) {
            discoveredDirs.putIfAbsent(rootDir.absolutePath, label to rootDir)
            collectDirectoriesAndFiles(rootDir, label, 0)
        }

        val folderSummariesByRelPath = LinkedHashMap<String, StorageFolderItem>()

        for ((absPath, pair) in discoveredDirs) {
            val (relDisplay, dir) = pair
            val stats = singlePassStatsMap[absPath] ?: RecursiveDirStats(0, 0, 0, 0L)
            val parentLabel = relDisplay.substringBeforeLast('/', "")
            val mediaFallback = mediaStoreFolderGroups[relDisplay].orEmpty()
            val mediaSubfoldersCount = mediaFallback.mapNotNull { item ->
                val afterPrefix = item.relativePathInStorage.removePrefix("$relDisplay/")
                afterPrefix.substringBeforeLast('/', "").takeIf { it.isNotBlank() }?.substringBefore('/')
            }.distinct().size

            val mergedFileCount = max(stats.fileCount, mediaFallback.size)
            val mergedSubfolderCount = max(stats.subfolderCount, mediaSubfoldersCount)
            val mergedBytes = max(stats.totalBytes, mediaFallback.sumOf { it.sizeBytes })
            val mergedModified = max(
                if (dir.exists()) dir.lastModified() else 0L,
                mediaFallback.maxOfOrNull { it.dateModifiedMillis } ?: 0L
            )
            val lowerRel = relDisplay.lowercase(Locale.ROOT)
            val isProtected = (lowerRel == "android/data" || lowerRel == "android/obb" ||
                lowerRel.startsWith("android/data/") || lowerRel.startsWith("android/obb/")) &&
                (!dir.canRead() || dir.listFiles() == null)

            val folderItem = StorageFolderItem(
                name = dir.name.ifBlank { relDisplay.substringAfterLast('/') },
                path = absPath,
                relativeDisplayPath = relDisplay,
                parentFolderName = parentLabel,
                fileCount = mergedFileCount,
                subfolderCount = mergedSubfolderCount,
                emptySubfolderCount = stats.emptySubfolderCount,
                totalBytes = mergedBytes,
                lastModifiedMillis = if (mergedModified > 0L) mergedModified else System.currentTimeMillis(),
                isProtectedSystemFolder = isProtected,
                protectionReason = if (isProtected) {
                    "مجلد نظام محمي في Android 11+ (${relDisplay})؛ يمنع النظام الوصول المباشر إليه."
                } else null,
                mediaStoreFallbackItems = mediaFallback
            )
            folderSummariesByRelPath[relDisplay] = folderItem
        }

        // Also include all MediaStore-discovered folders (top-level and nested folders)
        for ((relDisplay, itemsInGroup) in mediaStoreFolderGroups) {
            if (relDisplay !in folderSummariesByRelPath && itemsInGroup.isNotEmpty()) {
                val folderName = relDisplay.substringAfterLast('/')
                val parentLabel = relDisplay.substringBeforeLast('/', "")
                val candidateFile = rootDirMap[relDisplay] ?: File(externalRootPath, relDisplay)
                val nestedSubdirs = itemsInGroup.mapNotNull { item ->
                    val afterPrefix = item.relativePathInStorage.removePrefix("$relDisplay/")
                    afterPrefix.substringBeforeLast('/', "").takeIf { it.isNotBlank() }?.substringBefore('/')
                }.distinct().size

                folderSummariesByRelPath[relDisplay] = StorageFolderItem(
                    name = folderName,
                    path = candidateFile.absolutePath,
                    relativeDisplayPath = relDisplay,
                    parentFolderName = parentLabel,
                    fileCount = itemsInGroup.size,
                    subfolderCount = nestedSubdirs,
                    emptySubfolderCount = 0,
                    totalBytes = itemsInGroup.sumOf { it.sizeBytes },
                    lastModifiedMillis = itemsInGroup.maxOfOrNull { it.dateModifiedMillis } ?: System.currentTimeMillis(),
                    mediaStoreFallbackItems = itemsInGroup
                )
            }
        }

        // Ensure discovered rootDirMap folders are present in folderSummariesByRelPath
        for ((rootName, rootFile) in rootDirMap) {
            if (rootName !in folderSummariesByRelPath) {
                val mediaFallback = mediaStoreFolderGroups[rootName].orEmpty()
                val nestedSubdirs = mediaFallback.mapNotNull { item ->
                    val afterPrefix = item.relativePathInStorage.removePrefix("$rootName/")
                    afterPrefix.substringBeforeLast('/', "").takeIf { it.isNotBlank() }?.substringBefore('/')
                }.distinct().size
                folderSummariesByRelPath[rootName] = StorageFolderItem(
                    name = rootName,
                    path = rootFile.absolutePath,
                    relativeDisplayPath = rootName,
                    parentFolderName = "",
                    fileCount = mediaFallback.size,
                    subfolderCount = nestedSubdirs,
                    emptySubfolderCount = 0,
                    totalBytes = mediaFallback.sumOf { it.sizeBytes },
                    lastModifiedMillis = rootFile.lastModified().takeIf { it > 0L } ?: System.currentTimeMillis(),
                    mediaStoreFallbackItems = mediaFallback
                )
            }
        }

        val sortedFolders = folderSummariesByRelPath.values.sortedWith(
            compareBy<StorageFolderItem> { folder ->
                val rootIdx = STANDARD_ROOT_FOLDER_ORDER.indexOfFirst {
                    it.equals(folder.relativeDisplayPath, ignoreCase = true)
                }
                when {
                    rootIdx >= 0 -> rootIdx
                    !folder.relativeDisplayPath.contains('/') -> 15
                    folder.relativeDisplayPath.startsWith("Download/", ignoreCase = true) &&
                        !folder.name.equals("BarqSher", ignoreCase = true) -> 30
                    else -> 40
                }
            }
                .thenBy { it.name.lowercase(Locale.ROOT) }
        )

        return allFiles to sortedFolders
    }

    /**
     * Computes folder statistics on demand (e.g. when the user requests folder properties or selects a folder)
     * on a background thread with a bounded file inspection budget so it never blocks the UI.
     */
    fun computeFolderStatsOnDemand(
        folder: StorageFolderItem,
        maxBudget: Int = 500
    ): StorageFolderItem {
        val dir = File(folder.path)
        if (!dir.exists() || !dir.isDirectory || !dir.canRead()) return folder
        val stats = computeRecursiveDirStats(
            dir = dir,
            maxDepth = 6,
            remainingBudget = java.util.concurrent.atomic.AtomicInteger(maxBudget)
        )
        return folder.copy(
            fileCount = max(folder.fileCount, stats.fileCount),
            subfolderCount = max(folder.subfolderCount, stats.subfolderCount),
            emptySubfolderCount = max(folder.emptySubfolderCount, stats.emptySubfolderCount),
            totalBytes = max(folder.totalBytes, stats.totalBytes)
        )
    }

    private fun computeRecursiveDirStats(
        dir: File,
        maxDepth: Int = 6,
        visitedCanonical: MutableSet<String> = HashSet(),
        remainingBudget: java.util.concurrent.atomic.AtomicInteger = java.util.concurrent.atomic.AtomicInteger(250)
    ): RecursiveDirStats {
        if (maxDepth <= 0 || remainingBudget.get() <= 0 || !dir.exists() || !dir.isDirectory || !dir.canRead()) {
            return RecursiveDirStats(0, 0, 0, 0L)
        }
        val canon = try {
            dir.canonicalPath
        } catch (_: Exception) {
            dir.absolutePath
        }
        if (!visitedCanonical.add(canon)) {
            return RecursiveDirStats(0, 0, 0, 0L)
        }
        val list = dir.listFiles() ?: return RecursiveDirStats(0, 0, 0, 0L)
        var filesCount = 0
        var subfoldersCount = 0
        var emptySubfoldersCount = 0
        var bytesCount = 0L

        for (f in list) {
            if (remainingBudget.get() <= 0) break
            if (f.name.startsWith(".")) continue
            if (f.isDirectory && f.canRead()) {
                subfoldersCount++
                val sub = computeRecursiveDirStats(f, maxDepth - 1, visitedCanonical, remainingBudget)
                filesCount += sub.fileCount
                subfoldersCount += sub.subfolderCount
                emptySubfoldersCount += sub.emptySubfolderCount
                bytesCount += sub.totalBytes
                if (sub.fileCount == 0 && sub.subfolderCount == 0) {
                    emptySubfoldersCount++
                }
            } else if (f.isFile && f.canRead()) {
                remainingBudget.decrementAndGet()
                filesCount++
                bytesCount += f.length().coerceAtLeast(0L)
            }
        }
        return RecursiveDirStats(filesCount, subfoldersCount, emptySubfoldersCount, bytesCount)
    }

    data class FolderScanResult(
        val batchInfo: FolderBatchInfo?,
        val transferItems: List<TransferFileItem>,
        val previewMediaItems: List<DeviceMediaItem>,
        val errorMessage: String? = null
    )

    /**
     * Scans a selected StorageFolderItem (such as "Download/ropon") into a single unified FolderBatchInfo
     * and recursive list of TransferFileItems (preserving root folder name, relative paths, subfolders,
     * and empty directories), seamlessly merging local filesystem scan with MediaStore items if needed.
     */
    fun scanStorageFolderItemForTransfer(
        folderItem: StorageFolderItem,
        chunkSizeBytes: Int,
        context: Context? = null
    ): FolderScanResult {
        if (folderItem.isProtectedSystemFolder) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = folderItem.protectionReason
                    ?: "هذا المجلد (${folderItem.relativeDisplayPath}) محمي بسياسة نظام Android 11+ (Android/data أو Android/obb) ولا يسمح النظام بالوصول إليه."
            )
        }
        if (folderItem.safTreeUri != null && context != null) {
            return scanDocumentTreeForTransfer(
                context = context,
                treeUri = folderItem.safTreeUri,
                chunkSizeBytes = chunkSizeBytes,
                startDocId = folderItem.safDocumentId,
                customRootName = folderItem.name
            )
        }
        val rootDir = File(folderItem.path)
        val localResult = if (rootDir.exists() && rootDir.isDirectory && rootDir.canRead()) {
            scanLocalFolderForTransfer(rootDir, chunkSizeBytes)
        } else {
            null
        }

        val rootFolderName = sanitizePathSegment(folderItem.name.ifBlank { "Folder" })
        val batchId = localResult?.batchInfo?.batchId ?: "fld_${UUID.randomUUID().toString().take(8)}"
        val mergedTransferItems = mutableListOf<TransferFileItem>()
        val mergedPreviewItems = mutableListOf<DeviceMediaItem>()
        val seenRelPaths = HashSet<String>()

        if (localResult != null && localResult.errorMessage == null) {
            for (item in localResult.transferItems) {
                // Keep real files or empty subdirectories; if root itself was marked empty but we have MediaStore items, we'll replace it
                if (item.id.endsWith("_root_empty") && folderItem.mediaStoreFallbackItems.isNotEmpty()) continue
                mergedTransferItems.add(item)
                seenRelPaths.add(item.relativePath.lowercase(Locale.ROOT))
            }
            mergedPreviewItems.addAll(localResult.previewMediaItems)
        }

        // Merge any MediaStore-indexed files inside this folder that weren't returned by File.listFiles()
        val prefixToRemove = folderItem.relativeDisplayPath.trim('/').let { "$it/" }
        for (media in folderItem.mediaStoreFallbackItems) {
            val innerRel = if (media.relativePathInStorage.startsWith(prefixToRemove, ignoreCase = true)) {
                media.relativePathInStorage.substring(prefixToRemove.length)
            } else {
                media.name
            }
            val cleanSegments = innerRel.replace('\\', '/').split('/')
                .map { sanitizePathSegment(it) }
                .filter { it.isNotBlank() }
            val fullRelPath = if (cleanSegments.isEmpty()) {
                "$rootFolderName/${sanitizePathSegment(media.name)}"
            } else {
                "$rootFolderName/${cleanSegments.joinToString("/")}"
            }

            if (seenRelPaths.add(fullRelPath.lowercase(Locale.ROOT))) {
                val size = media.sizeBytes.coerceAtLeast(0L)
                val chunks = max(1, ((size + chunkSizeBytes - 1) / chunkSizeBytes).toInt())
                mergedTransferItems.add(
                    TransferFileItem(
                        id = "${batchId}_ms_${mergedTransferItems.size}",
                        name = cleanSegments.lastOrNull() ?: sanitizePathSegment(media.name),
                        sizeBytes = size,
                        category = media.category,
                        uri = media.uri,
                        localFile = media.localFile,
                        relativePath = fullRelPath,
                        rootFolderName = rootFolderName,
                        folderBatchId = batchId,
                        isDirectory = false,
                        totalChunks = chunks,
                        sha256Expected = if (size == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
                    )
                )
                mergedPreviewItems.add(media)
            }
        }

        if (mergedTransferItems.isEmpty()) {
            if (!rootDir.exists() && folderItem.mediaStoreFallbackItems.isEmpty()) {
                return FolderScanResult(
                    batchInfo = null,
                    transferItems = emptyList(),
                    previewMediaItems = emptyList(),
                    errorMessage = "المجلد المحدد (${folderItem.relativeDisplayPath}) غير موجود أو لا يمكن الوصول إليه"
                )
            }
            // Empty root folder: still transfer it as an empty directory unit so receiver creates it
            mergedTransferItems.add(
                TransferFileItem(
                    id = "${batchId}_root_empty",
                    name = rootFolderName,
                    sizeBytes = 0L,
                    category = FileCategory.FOLDER,
                    localFile = rootDir.takeIf { it.exists() },
                    relativePath = rootFolderName,
                    rootFolderName = rootFolderName,
                    folderBatchId = batchId,
                    isDirectory = true,
                    totalChunks = 1,
                    sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                )
            )
        }

        val totalFiles = mergedTransferItems.count { !it.isDirectory }
        val emptyDirs = mergedTransferItems.count { it.isDirectory }
        val totalSubfolders = max(
            localResult?.batchInfo?.totalSubfoldersCount ?: folderItem.subfolderCount,
            emptyDirs
        )
        val totalBytes = mergedTransferItems.filter { !it.isDirectory }.sumOf { it.sizeBytes }

        val batchInfo = FolderBatchInfo(
            batchId = batchId,
            rootFolderName = rootFolderName,
            sourceUriOrPath = folderItem.relativeDisplayPath.ifBlank { folderItem.path },
            totalFilesCount = totalFiles,
            totalSubfoldersCount = totalSubfolders,
            emptyFoldersCount = emptyDirs,
            totalBytes = totalBytes,
            skippedUnreadableCount = localResult?.batchInfo?.skippedUnreadableCount ?: 0,
            hasPersistentPermission = true
        )

        return FolderScanResult(
            batchInfo = batchInfo,
            transferItems = mergedTransferItems,
            previewMediaItems = mergedPreviewItems,
            errorMessage = null
        )
    }

    /**
     * Recursively reads an entire user-selected folder from ACTION_OPEN_DOCUMENT_TREE,
     * persisting read permissions and building a unified transfer manifest that preserves
     * all nested subdirectories, relative paths, empty folders, and 0-byte files.
     */
    fun scanDocumentTreeForTransfer(
        context: Context,
        treeUri: Uri,
        chunkSizeBytes: Int,
        startDocId: String? = null,
        customRootName: String? = null
    ): FolderScanResult {
        val resolver = context.contentResolver
        var hasPersistentPerm = false
        try {
            resolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            hasPersistentPerm = true
        } catch (_: SecurityException) {
            // Provider may only grant transient session read permission
        } catch (_: Exception) {
        }

        val rootDocId = startDocId ?: try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (e: Exception) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "تعذر قراءة معرّف المجلد المختار: ${e.localizedMessage ?: "URI غير صالح"}"
            )
        }

        val lowerDocId = rootDocId.lowercase(Locale.ROOT)
        if (lowerDocId.contains("android/data") || lowerDocId.contains("android/obb")) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "هذا المجلد (${rootDocId}) محمي من نظام Android 11+ (Android/data أو Android/obb) ولا يسمح النظام بالوصول إليه بدون صلاحيات خاصة."
            )
        }

        val rootFolderName = sanitizePathSegment(
            customRootName?.takeIf { it.isNotBlank() } ?: resolveTreeRootFolderName(resolver, treeUri, rootDocId)
        )
        val batchId = "fld_${UUID.randomUUID().toString().take(8)}"
        val transferItems = mutableListOf<TransferFileItem>()
        val previewItems = mutableListOf<DeviceMediaItem>()
        var totalFilesCount = 0
        var totalSubfoldersCount = 0
        var emptyFoldersCount = 0
        var totalBytes = 0L
        var skippedUnreadableCount = 0

        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )

        val visitedDocIds = HashSet<String>()

        fun traverseDir(currentDocId: String, currentRelPath: String, depth: Int): Int {
            if (depth > 24 || !visitedDocIds.add(currentDocId)) return 0
            val childrenUri = try {
                DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, currentDocId)
            } catch (_: Exception) {
                skippedUnreadableCount++
                return 0
            }

            var entriesInThisDir = 0
            val usedSiblingNames = HashSet<String>()

            try {
                val cursor = resolver.query(childrenUri, projection, null, null, null)
                if (cursor == null) {
                    skippedUnreadableCount++
                    return 0
                }
                cursor.use { c ->
                    val idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                    val nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                    val sizeCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                    val dateCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                    val mimeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)

                    while (c.moveToNext()) {
                        val childDocId = c.getString(idCol) ?: continue
                        val rawName = c.getString(nameCol) ?: "عنصر_${entriesInThisDir + 1}"
                        val safeName = deduplicateSiblingName(sanitizePathSegment(rawName), usedSiblingNames)
                        val mime = if (mimeCol >= 0) c.getString(mimeCol) else null
                        val lastMod = if (dateCol >= 0 && !c.isNull(dateCol)) c.getLong(dateCol) else System.currentTimeMillis()
                        val childRelPath = "$currentRelPath/$safeName"
                        entriesInThisDir++

                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            totalSubfoldersCount++
                            val subEntries = traverseDir(childDocId, childRelPath, depth + 1)
                            if (subEntries == 0) {
                                // Empty subfolder: add explicit directory item so receiver recreates it
                                emptyFoldersCount++
                                transferItems.add(
                                    TransferFileItem(
                                        id = "${batchId}_dir_${transferItems.size}",
                                        name = safeName,
                                        sizeBytes = 0L,
                                        category = FileCategory.FOLDER,
                                        relativePath = childRelPath,
                                        rootFolderName = rootFolderName,
                                        folderBatchId = batchId,
                                        isDirectory = true,
                                        totalChunks = 1,
                                        sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                                    )
                                )
                            }
                        } else {
                            var size = if (!c.isNull(sizeCol)) c.getLong(sizeCol).coerceAtLeast(0L) else 0L
                            val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childDocId)
                            if (size == 0L) {
                                try {
                                    resolver.openAssetFileDescriptor(childUri, "r")?.use { afd ->
                                        if (afd.length > 0) size = afd.length
                                    }
                                } catch (_: Exception) {
                                }
                            }
                            val chunks = max(1, ((size + chunkSizeBytes - 1) / chunkSizeBytes).toInt())
                            val cat = FileCategory.fromFileName(safeName, mime)
                            totalFilesCount++
                            totalBytes += size

                            transferItems.add(
                                TransferFileItem(
                                    id = "${batchId}_f_${transferItems.size}",
                                    name = safeName,
                                    sizeBytes = size,
                                    category = cat,
                                    uri = childUri,
                                    relativePath = childRelPath,
                                    rootFolderName = rootFolderName,
                                    folderBatchId = batchId,
                                    isDirectory = false,
                                    totalChunks = chunks,
                                    sha256Expected = if (size == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
                                )
                            )
                            previewItems.add(
                                DeviceMediaItem(
                                    id = "saf_${childUri.hashCode()}_${previewItems.size}",
                                    name = childRelPath,
                                    uri = childUri,
                                    sizeBytes = size,
                                    dateModifiedMillis = lastMod,
                                    mimeType = mime,
                                    bucketOrFolderName = rootFolderName,
                                    category = cat
                                )
                            )
                        }
                    }
                }
            } catch (se: SecurityException) {
                Log.w(LOG_TAG, "SAF SecurityException reading $currentRelPath: ${se.message}")
                skippedUnreadableCount++
            } catch (e: Exception) {
                Log.w(LOG_TAG, "SAF error reading $currentRelPath: ${e.message}")
                skippedUnreadableCount++
            }
            return entriesInThisDir
        }

        val rootEntries = traverseDir(rootDocId, rootFolderName, 0)
        if (rootEntries == 0 && skippedUnreadableCount > 0 && transferItems.isEmpty()) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "تعذر قراءة محتويات المجلد ($rootFolderName) لأن نظام Android يقيد الوصول إليه."
            )
        }

        // If the selected root folder itself is completely empty, still transfer it as an empty directory
        if (transferItems.isEmpty()) {
            emptyFoldersCount = 1
            transferItems.add(
                TransferFileItem(
                    id = "${batchId}_root_empty",
                    name = rootFolderName,
                    sizeBytes = 0L,
                    category = FileCategory.FOLDER,
                    relativePath = rootFolderName,
                    rootFolderName = rootFolderName,
                    folderBatchId = batchId,
                    isDirectory = true,
                    totalChunks = 1,
                    sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                )
            )
        }

        val batchInfo = FolderBatchInfo(
            batchId = batchId,
            rootFolderName = rootFolderName,
            sourceUriOrPath = treeUri.toString(),
            totalFilesCount = totalFilesCount,
            totalSubfoldersCount = totalSubfoldersCount,
            emptyFoldersCount = emptyFoldersCount,
            totalBytes = totalBytes,
            skippedUnreadableCount = skippedUnreadableCount,
            hasPersistentPermission = hasPersistentPerm
        )

        return FolderScanResult(
            batchInfo = batchInfo,
            transferItems = transferItems,
            previewMediaItems = previewItems,
            errorMessage = null
        )
    }

    /**
     * Recursively scans a local java.io.File directory to send the entire folder as one unit,
     * preserving nested subfolders, relative paths, empty directories, and 0-byte files.
     */
    fun scanLocalFolderForTransfer(
        rootDir: File,
        chunkSizeBytes: Int
    ): FolderScanResult {
        if (!rootDir.exists() || !rootDir.isDirectory) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "المجلد المحدد غير موجود على الجهاز"
            )
        }
        if (!rootDir.canRead()) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "هذا المجلد (${rootDir.name}) محمي من نظام Android ولا يمكن قراءته بدون إذن خاص"
            )
        }

        val rootFolderName = sanitizePathSegment(rootDir.name.ifBlank { "Folder" })
        val batchId = "fld_${UUID.randomUUID().toString().take(8)}"
        val transferItems = mutableListOf<TransferFileItem>()
        val previewItems = mutableListOf<DeviceMediaItem>()
        var totalFilesCount = 0
        var totalSubfoldersCount = 0
        var emptyFoldersCount = 0
        var totalBytes = 0L
        var skippedUnreadableCount = 0
        val visitedCanonicalPaths = HashSet<String>()

        fun traverseLocal(currentDir: File, currentRelPath: String, depth: Int): Int {
            if (depth > 24) return 0
            if (!currentDir.canRead()) {
                skippedUnreadableCount++
                return 0
            }
            val canon = try {
                currentDir.canonicalPath
            } catch (_: Exception) {
                currentDir.absolutePath
            }
            if (!visitedCanonicalPaths.add(canon)) {
                return 0
            }
            val children = currentDir.listFiles()
            if (children == null) {
                skippedUnreadableCount++
                return 0
            }

            val sortedChildren = children.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase(Locale.ROOT) }))
            val usedSiblingNames = HashSet<String>()
            var entriesInThisDir = 0

            for (child in sortedChildren) {
                val safeName = deduplicateSiblingName(sanitizePathSegment(child.name), usedSiblingNames)
                val childRelPath = "$currentRelPath/$safeName"
                entriesInThisDir++

                if (child.isDirectory) {
                    totalSubfoldersCount++
                    val subCount = traverseLocal(child, childRelPath, depth + 1)
                    if (subCount == 0) {
                        emptyFoldersCount++
                        transferItems.add(
                            TransferFileItem(
                                id = "${batchId}_dir_${transferItems.size}",
                                name = safeName,
                                sizeBytes = 0L,
                                category = FileCategory.FOLDER,
                                localFile = child,
                                relativePath = childRelPath,
                                rootFolderName = rootFolderName,
                                folderBatchId = batchId,
                                isDirectory = true,
                                totalChunks = 1,
                                sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                            )
                        )
                    }
                } else if (child.isFile) {
                    if (!child.canRead()) {
                        skippedUnreadableCount++
                        continue
                    }
                    val size = child.length().coerceAtLeast(0L)
                    val chunks = max(1, ((size + chunkSizeBytes - 1) / chunkSizeBytes).toInt())
                    val cat = FileCategory.fromFileName(safeName)
                    totalFilesCount++
                    totalBytes += size

                    transferItems.add(
                        TransferFileItem(
                            id = "${batchId}_f_${transferItems.size}",
                            name = safeName,
                            sizeBytes = size,
                            category = cat,
                            localFile = child,
                            relativePath = childRelPath,
                            rootFolderName = rootFolderName,
                            folderBatchId = batchId,
                            isDirectory = false,
                            totalChunks = chunks,
                            sha256Expected = if (size == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
                        )
                    )
                    previewItems.add(
                        DeviceMediaItem(
                            id = "local_${child.absolutePath.hashCode()}",
                            name = childRelPath,
                            localFile = child,
                            sizeBytes = size,
                            dateModifiedMillis = child.lastModified(),
                            bucketOrFolderName = rootFolderName,
                            category = cat
                        )
                    )
                }
            }
            return entriesInThisDir
        }

        traverseLocal(rootDir, rootFolderName, 0)

        if (transferItems.isEmpty()) {
            emptyFoldersCount = 1
            transferItems.add(
                TransferFileItem(
                    id = "${batchId}_root_empty",
                    name = rootFolderName,
                    sizeBytes = 0L,
                    category = FileCategory.FOLDER,
                    localFile = rootDir,
                    relativePath = rootFolderName,
                    rootFolderName = rootFolderName,
                    folderBatchId = batchId,
                    isDirectory = true,
                    totalChunks = 1,
                    sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                )
            )
        }

        val batchInfo = FolderBatchInfo(
            batchId = batchId,
            rootFolderName = rootFolderName,
            sourceUriOrPath = rootDir.absolutePath,
            totalFilesCount = totalFilesCount,
            totalSubfoldersCount = totalSubfoldersCount,
            emptyFoldersCount = emptyFoldersCount,
            totalBytes = totalBytes,
            skippedUnreadableCount = skippedUnreadableCount,
            hasPersistentPermission = true
        )

        return FolderScanResult(
            batchInfo = batchInfo,
            transferItems = transferItems,
            previewMediaItems = previewItems,
            errorMessage = null
        )
    }

    private fun resolveTreeRootFolderName(
        resolver: ContentResolver,
        treeUri: Uri,
        rootDocId: String
    ): String {
        try {
            val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootDocId)
            resolver.query(
                docUri,
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null,
                null,
                null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val name = c.getString(0)
                    if (!name.isNullOrBlank()) return name
                }
            }
        } catch (_: Exception) {
        }
        val decoded = try {
            URLDecoder.decode(rootDocId, "UTF-8")
        } catch (_: Exception) {
            rootDocId
        }
        return decoded.substringAfterLast(':').substringAfterLast('/').ifBlank { "مجلد_مرسل" }
    }

    fun sanitizePathSegment(raw: String): String {
        val cleaned = raw.trim()
            .replace('\\', '_')
            .replace('/', '_')
            .replace(":", "_")
            .replace("*", "_")
            .replace("?", "_")
            .replace("\"", "_")
            .replace("<", "_")
            .replace(">", "_")
            .replace("|", "_")
        return if (cleaned.isBlank() || cleaned == "." || cleaned == "..") "مجلد" else cleaned
    }

    fun deduplicateSiblingName(baseName: String, usedNamesLower: MutableSet<String>): String {
        val lower = baseName.lowercase(Locale.ROOT)
        if (usedNamesLower.add(lower)) return baseName
        val dotIdx = baseName.lastIndexOf('.')
        val stem = if (dotIdx > 0) baseName.substring(0, dotIdx) else baseName
        val ext = if (dotIdx > 0) baseName.substring(dotIdx) else ""
        var counter = 1
        while (true) {
            val candidate = "$stem ($counter)$ext"
            if (usedNamesLower.add(candidate.lowercase(Locale.ROOT))) {
                return candidate
            }
            counter++
        }
    }

    /**
     * Reads files inside a user-picked SAF folder (OpenDocumentTree) for previewing in Files tab.
     */
    fun loadFilesFromDocumentTree(context: Context, treeUri: Uri): List<DeviceMediaItem> {
        return scanDocumentTreeForTransfer(context, treeUri, 1024 * 1024).previewMediaItems
    }

    /**
     * Returns all persisted SAF directory trees granted by the user via ACTION_OPEN_DOCUMENT_TREE.
     */
    fun loadPersistedSafFolders(context: Context): List<PersistedSafFolderItem> {
        val resolver = context.contentResolver
        val result = mutableListOf<PersistedSafFolderItem>()
        try {
            val perms = resolver.persistedUriPermissions
            for (perm in perms) {
                if (!perm.isReadPermission) continue
                val uri = perm.uri
                val docId = try {
                    DocumentsContract.getTreeDocumentId(uri)
                } catch (_: Exception) {
                    continue
                }
                val name = resolveTreeRootFolderName(resolver, uri, docId)
                result.add(
                    PersistedSafFolderItem(
                        uri = uri,
                        displayName = name,
                        documentId = docId
                    )
                )
            }
        } catch (_: Exception) {
        }
        return result
    }

    /**
     * Lists the immediate child folders and files inside a granted SAF tree URI (at root or any nested documentId),
     * enabling full hierarchical folder navigation and selection inside SAF directories.
     */
    fun browseSafDirectoryChildren(
        context: Context,
        treeUri: Uri,
        parentDocId: String?,
        parentDisplayPath: String
    ): Pair<List<StorageFolderItem>, List<DeviceMediaItem>> {
        val resolver = context.contentResolver
        val docId = parentDocId ?: try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (_: Exception) {
            return emptyList<StorageFolderItem>() to emptyList()
        }

        val childFolders = mutableListOf<StorageFolderItem>()
        val childFiles = mutableListOf<DeviceMediaItem>()
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )

        try {
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            resolver.query(childrenUri, projection, null, null, null)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val sizeCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                val dateCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                val mimeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)

                while (c.moveToNext()) {
                    val childDocId = c.getString(idCol) ?: continue
                    val rawName = c.getString(nameCol) ?: "عنصر"
                    val mime = if (mimeCol >= 0) c.getString(mimeCol) else null
                    val lastMod = if (dateCol >= 0 && !c.isNull(dateCol)) c.getLong(dateCol) else System.currentTimeMillis()
                    val cleanParent = parentDisplayPath.trim('/')
                    val childRelPath = if (cleanParent.isEmpty()) rawName else "$cleanParent/$rawName"

                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        // Compute quick child count for this SAF subfolder
                        var subFiles = 0
                        var subFolders = 0
                        var subBytes = 0L
                        try {
                            val subUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, childDocId)
                            resolver.query(subUri, projection, null, null, null)?.use { sc ->
                                val sSizeCol = sc.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                                val sMimeCol = sc.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
                                while (sc.moveToNext()) {
                                    val sm = if (sMimeCol >= 0) sc.getString(sMimeCol) else null
                                    if (sm == DocumentsContract.Document.MIME_TYPE_DIR) {
                                        subFolders++
                                    } else {
                                        subFiles++
                                        if (!sc.isNull(sSizeCol)) {
                                            subBytes += sc.getLong(sSizeCol).coerceAtLeast(0L)
                                        }
                                    }
                                }
                            }
                        } catch (_: Exception) {
                        }
                        childFolders.add(
                            StorageFolderItem(
                                name = rawName,
                                path = "saf://$treeUri#$childDocId",
                                relativeDisplayPath = childRelPath,
                                parentFolderName = cleanParent,
                                fileCount = subFiles,
                                subfolderCount = subFolders,
                                emptySubfolderCount = if (subFiles == 0 && subFolders == 0) 1 else 0,
                                totalBytes = subBytes,
                                lastModifiedMillis = lastMod,
                                safTreeUri = treeUri,
                                safDocumentId = childDocId
                            )
                        )
                    } else {
                        val size = if (!c.isNull(sizeCol)) c.getLong(sizeCol).coerceAtLeast(0L) else 0L
                        val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childDocId)
                        childFiles.add(
                            DeviceMediaItem(
                                id = "saf_nav_${childUri.hashCode()}",
                                name = rawName,
                                uri = childUri,
                                sizeBytes = size,
                                dateModifiedMillis = lastMod,
                                mimeType = mime,
                                bucketOrFolderName = cleanParent,
                                relativePathInStorage = childRelPath,
                                category = FileCategory.fromFileName(rawName, mime)
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {
        }
        return childFolders to childFiles
    }

    /**
     * Lists the immediate child folders and immediate child files inside the root of shared internal storage
     * (when browsingRelOrAbsPath is blank or "/") or inside a specific relative/absolute folder path
     * (e.g. "Download", "Android", "DCIM", "Download/ropon"), merging actual filesystem contents with
     * MediaStore-indexed items without blocking or recursively scanning nested subfolders.
     */
    fun browseLocalDirectoryChildren(
        browsingRelOrAbsPath: String,
        allKnownFolders: List<StorageFolderItem>,
        allKnownFiles: List<DeviceMediaItem>,
        onPartialResult: ((List<StorageFolderItem>, List<DeviceMediaItem>) -> Unit)? = null,
        isCancelled: () -> Boolean = { false }
    ): Pair<List<StorageFolderItem>, List<DeviceMediaItem>> {
        if (isCancelled()) return emptyList<StorageFolderItem>() to emptyList()

        @Suppress("DEPRECATION")
        val extRoot = try {
            Environment.getExternalStorageDirectory()
        } catch (_: Exception) {
            null
        }
        val externalRootPath = extRoot?.absolutePath?.trimEnd('/') ?: "/storage/emulated/0"
        val cleanRel = browsingRelOrAbsPath.trim().trim('/').replace('\\', '/')
        val isRootBrowsing = cleanRel.isEmpty()

        // Build O(1) lookup maps so we never run O(N * M) linear scans on large directories
        val knownFoldersByRel = HashMap<String, StorageFolderItem>(allKnownFolders.size * 2 + 16)
        val knownFoldersByPath = HashMap<String, StorageFolderItem>(allKnownFolders.size * 2 + 16)
        for (f in allKnownFolders) {
            knownFoldersByRel.putIfAbsent(f.relativeDisplayPath.trim('/').lowercase(Locale.ROOT), f)
            knownFoldersByPath.putIfAbsent(f.path, f)
        }

        val knownFilesByPath = HashMap<String, DeviceMediaItem>(allKnownFiles.size * 2 + 16)
        val knownFilesByRel = HashMap<String, DeviceMediaItem>(allKnownFiles.size * 2 + 16)
        for (file in allKnownFiles) {
            file.localFile?.absolutePath?.let { knownFilesByPath.putIfAbsent(it, file) }
            val r = file.relativePathInStorage.trim('/').lowercase(Locale.ROOT)
            if (r.isNotBlank()) knownFilesByRel.putIfAbsent(r, file)
        }

        if (isRootBrowsing) {
            val rootFolders = LinkedHashMap<String, StorageFolderItem>()
            val rootFiles = LinkedHashMap<String, DeviceMediaItem>()

            // 1. Read actual root of shared internal storage (/storage/emulated/0)
            if (extRoot != null && extRoot.exists() && extRoot.canRead()) {
                val rawRootChildren = extRoot.listFiles().orEmpty()
                for (child in rawRootChildren) {
                    if (isCancelled()) return emptyList<StorageFolderItem>() to emptyList()
                    if (child.name.startsWith(".")) continue
                    val keyLower = child.name.lowercase(Locale.ROOT)
                    if (child.isDirectory) {
                        val existing = knownFoldersByRel[keyLower] ?: knownFoldersByPath[child.absolutePath]
                        if (existing != null) {
                            rootFolders[keyLower] = existing
                        } else {
                            rootFolders[keyLower] = StorageFolderItem(
                                name = child.name,
                                path = child.absolutePath,
                                relativeDisplayPath = child.name,
                                parentFolderName = "",
                                fileCount = 0,
                                subfolderCount = 0,
                                emptySubfolderCount = 0,
                                totalBytes = 0L,
                                lastModifiedMillis = child.lastModified().takeIf { it > 0L } ?: System.currentTimeMillis()
                            )
                        }
                    } else if (child.isFile && child.canRead()) {
                        val existingFile = knownFilesByPath[child.absolutePath] ?: knownFilesByRel[keyLower]
                        val mediaItem = existingFile ?: DeviceMediaItem(
                            id = "root_disk_${child.absolutePath.hashCode()}",
                            name = child.name,
                            localFile = child,
                            sizeBytes = child.length().coerceAtLeast(0L),
                            dateModifiedMillis = child.lastModified(),
                            bucketOrFolderName = "",
                            relativePathInStorage = child.name,
                            category = FileCategory.fromFileName(child.name)
                        )
                        rootFiles[keyLower] = mediaItem
                    }
                }
            }

            // 2. Merge top-level folders discovered via MediaStore or standard Android public directories + SDCard
            for (folder in allKnownFolders) {
                val rel = folder.relativeDisplayPath.trim('/')
                if (rel.isNotBlank() && !rel.contains('/')) {
                    rootFolders.putIfAbsent(rel.lowercase(Locale.ROOT), folder)
                }
            }
            for (file in allKnownFiles) {
                val rel = file.relativePathInStorage.trim('/')
                if (rel.isNotBlank() && !rel.contains('/') && file.bucketOrFolderName.isBlank()) {
                    rootFiles.putIfAbsent(file.name.lowercase(Locale.ROOT), file)
                }
            }

            // 3. Ensure core Android root directories are present even before MediaStore finishes indexing
            val coreRootNames = listOf("Download", "DCIM", "Pictures", "Movies", "Documents", "Music", "Android")
            for (coreName in coreRootNames) {
                val keyLower = coreName.lowercase(Locale.ROOT)
                if (keyLower !in rootFolders) {
                    val f = File(externalRootPath, coreName)
                    rootFolders[keyLower] = StorageFolderItem(
                        name = coreName,
                        path = f.absolutePath,
                        relativeDisplayPath = coreName,
                        parentFolderName = "",
                        fileCount = 0,
                        subfolderCount = 0,
                        emptySubfolderCount = 0,
                        totalBytes = 0L,
                        lastModifiedMillis = if (f.exists()) f.lastModified() else System.currentTimeMillis()
                    )
                }
            }

            return rootFolders.values.toList() to rootFiles.values.toList()
        }

        val matchingFolder = knownFoldersByRel[cleanRel.lowercase(Locale.ROOT)]
            ?: knownFoldersByPath[browsingRelOrAbsPath.trim()]
        val targetDir: File? = when {
            matchingFolder != null -> File(matchingFolder.path)
            File(browsingRelOrAbsPath).isAbsolute -> File(browsingRelOrAbsPath)
            extRoot != null -> File(extRoot, cleanRel)
            else -> File(externalRootPath, cleanRel)
        }
        val displayPrefix = matchingFolder?.relativeDisplayPath?.trim('/') ?: cleanRel

        val immediateSubfolders = LinkedHashMap<String, StorageFolderItem>()
        val immediateFiles = LinkedHashMap<String, DeviceMediaItem>()
        var partialEmitted = false

        // 1. Inspect direct filesystem children of targetDir WITHOUT recursive subfolder traversal
        if (targetDir != null && targetDir.exists() && targetDir.isDirectory && targetDir.canRead()) {
            val rawChildren = targetDir.listFiles()
            if (rawChildren != null && rawChildren.isNotEmpty()) {
                // Only allow a small shared shallow inspection budget if the directory has very few items (<= 25)
                val sharedSmallBudget = java.util.concurrent.atomic.AtomicInteger(if (rawChildren.size <= 25) 60 else 0)

                for (idx in rawChildren.indices) {
                    if ((idx and 63) == 0 && isCancelled()) {
                        return immediateSubfolders.values.toList() to immediateFiles.values.toList()
                    }
                    val child = rawChildren[idx]
                    val name = child.name
                    if (name.isEmpty() || name.startsWith(".")) continue
                    val childRel = if (displayPrefix.isBlank()) name else "$displayPrefix/$name"
                    val childRelLower = childRel.lowercase(Locale.ROOT)

                    if (child.isDirectory) {
                        val lowerAbs = child.absolutePath.lowercase(Locale.ROOT)
                        val isProtected = (lowerAbs.endsWith("/android/data") || lowerAbs.endsWith("/android/obb") ||
                            lowerAbs.contains("/android/data/") || lowerAbs.contains("/android/obb/")) &&
                            (!child.canRead() || child.listFiles() == null)

                        val existingSummary = knownFoldersByRel[childRelLower] ?: knownFoldersByPath[child.absolutePath]
                        if (existingSummary != null && (existingSummary.fileCount > 0 || existingSummary.subfolderCount > 0 || sharedSmallBudget.get() <= 0)) {
                            immediateSubfolders[childRelLower] = existingSummary.copy(
                                isProtectedSystemFolder = existingSummary.isProtectedSystemFolder || isProtected,
                                protectionReason = existingSummary.protectionReason ?: if (isProtected) {
                                    "مجلد نظام محمي في Android 11+ (${childRel})؛ يمنع النظام الوصول المباشر إليه لحماية خصوصية التطبيقات."
                                } else null
                            )
                        } else if (!isProtected && sharedSmallBudget.get() > 0 && child.canRead()) {
                            val quickStats = computeRecursiveDirStats(
                                dir = child,
                                maxDepth = 4,
                                remainingBudget = sharedSmallBudget
                            )
                            immediateSubfolders[childRelLower] = StorageFolderItem(
                                name = name,
                                path = child.absolutePath,
                                relativeDisplayPath = childRel,
                                parentFolderName = displayPrefix,
                                fileCount = quickStats.fileCount,
                                subfolderCount = quickStats.subfolderCount,
                                emptySubfolderCount = quickStats.emptySubfolderCount,
                                totalBytes = quickStats.totalBytes,
                                lastModifiedMillis = child.lastModified(),
                                isProtectedSystemFolder = false
                            )
                        } else {
                            immediateSubfolders[childRelLower] = StorageFolderItem(
                                name = name,
                                path = child.absolutePath,
                                relativeDisplayPath = childRel,
                                parentFolderName = displayPrefix,
                                fileCount = existingSummary?.fileCount ?: 0,
                                subfolderCount = existingSummary?.subfolderCount ?: 0,
                                emptySubfolderCount = existingSummary?.emptySubfolderCount ?: 0,
                                totalBytes = existingSummary?.totalBytes ?: 0L,
                                lastModifiedMillis = child.lastModified(),
                                isProtectedSystemFolder = isProtected,
                                protectionReason = if (isProtected) {
                                    "مجلد نظام محمي في Android 11+ (${childRel})؛ يمنع النظام الوصول المباشر إليه لحماية خصوصية التطبيقات."
                                } else null
                            )
                        }
                    } else if (child.isFile) {
                        val existingFile = knownFilesByPath[child.absolutePath] ?: knownFilesByRel[childRelLower]
                        val mediaItem = existingFile ?: DeviceMediaItem(
                            id = "disk_${child.absolutePath.hashCode()}",
                            name = name,
                            localFile = child,
                            sizeBytes = child.length().coerceAtLeast(0L),
                            dateModifiedMillis = child.lastModified(),
                            bucketOrFolderName = displayPrefix,
                            relativePathInStorage = childRel,
                            category = FileCategory.fromFileName(name)
                        )
                        immediateFiles[name.lowercase(Locale.ROOT)] = mediaItem
                    }

                    // Emit first progressive batch immediately for large directories so UI renders in < 30ms
                    if (!partialEmitted && rawChildren.size > 140 && (immediateSubfolders.size + immediateFiles.size) >= 100) {
                        partialEmitted = true
                        onPartialResult?.invoke(
                            immediateSubfolders.values.toList(),
                            immediateFiles.values.toList()
                        )
                    }
                }
            }
        }

        // Special support when browsing "Android": ensure data, media, and obb subfolders are visible with accurate OS protection status
        if (displayPrefix.equals("Android", ignoreCase = true) && targetDir != null) {
            for (subName in listOf("media", "data", "obb")) {
                val subRel = "Android/$subName"
                val subRelLower = subRel.lowercase(Locale.ROOT)
                if (subRelLower !in immediateSubfolders) {
                    val subFile = File(targetDir, subName)
                    val isRestricted = (subName == "data" || subName == "obb") &&
                        (!subFile.exists() || !subFile.canRead() || subFile.listFiles() == null)
                    if (subFile.exists() || subName == "data" || subName == "obb" || subName == "media") {
                        immediateSubfolders[subRelLower] = StorageFolderItem(
                            name = subName,
                            path = subFile.absolutePath,
                            relativeDisplayPath = subRel,
                            parentFolderName = "Android",
                            fileCount = 0,
                            subfolderCount = 0,
                            emptySubfolderCount = 0,
                            totalBytes = 0L,
                            lastModifiedMillis = if (subFile.exists()) subFile.lastModified() else System.currentTimeMillis(),
                            isProtectedSystemFolder = isRestricted,
                            protectionReason = if (isRestricted) {
                                "يقيد نظام Android 11+ الوصول المباشر إلى ($subRel) لحماية بيانات التطبيقات. يمكنك استخدام SAF للمجلدات المسموحة."
                            } else null
                        )
                    }
                }
            }
        }

        // 2. Merge immediate subfolders and immediate files from MediaStore / allKnownFolders
        val prefixSlash = "$displayPrefix/"
        for (folder in allKnownFolders) {
            val rel = folder.relativeDisplayPath.trim('/')
            if (rel.startsWith(prefixSlash, ignoreCase = true)) {
                val remainder = rel.substring(prefixSlash.length)
                if (remainder.isNotBlank() && !remainder.contains('/')) {
                    val key = rel.lowercase(Locale.ROOT)
                    val current = immediateSubfolders[key]
                    if (current == null || (current.fileCount == 0 && folder.fileCount > 0)) {
                        immediateSubfolders[key] = folder
                    }
                }
            }
        }
        for (file in allKnownFiles) {
            val relFile = file.relativePathInStorage.trim('/')
            if (file.bucketOrFolderName.equals(displayPrefix, ignoreCase = true)) {
                immediateFiles.putIfAbsent(file.name.lowercase(Locale.ROOT), file)
            } else if (relFile.startsWith(prefixSlash, ignoreCase = true)) {
                val remainder = relFile.substring(prefixSlash.length)
                if (remainder.isNotBlank() && !remainder.contains('/')) {
                    immediateFiles.putIfAbsent(file.name.lowercase(Locale.ROOT), file)
                }
            }
        }

        return immediateSubfolders.values.toList() to immediateFiles.values.toList()
    }

    /**
     * Scans received/downloaded APK files from the BarqSher download directory, public Downloads,
     * and transfer history records. Validates each APK via PackageManager.getPackageArchiveInfo
     * and ZIP header inspection, extracting the real App Name, Icon, Package Name, Version, and Status.
     */
    fun loadReceivedApkFiles(
        context: Context,
        @Suppress("DEPRECATION")
        downloadDir: File = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "BarqSher"
        ),
        historyRecords: List<TransferHistoryRecord> = emptyList()
    ): List<ReceivedApkItem> {
        val candidateFiles = LinkedHashMap<String, Pair<File, Boolean>>()

        // 1. From transfer history records (received APKs)
        for (rec in historyRecords) {
            val savedPath = rec.savedPath ?: continue
            val f = File(savedPath)
            if (f.exists() && f.isFile && f.canRead() &&
                (f.name.endsWith(".apk", ignoreCase = true) || f.name.endsWith(".apk.part", ignoreCase = true))
            ) {
                candidateFiles[f.absolutePath] = f to rec.sha256Verified
            }
        }

        // 2. Recursively scan downloadDir (Downloads/BarqSher) and top-level Downloads for .apk / .apk.part
        val visitedCanon = HashSet<String>()
        fun scanDirForApks(dir: File, depth: Int) {
            if (depth > 3 || !dir.exists() || !dir.isDirectory || !dir.canRead()) return
            val canon = try {
                dir.canonicalPath
            } catch (_: Exception) {
                dir.absolutePath
            }
            if (!visitedCanon.add(canon)) return
            val children = dir.listFiles() ?: return
            for (child in children) {
                if (child.name.startsWith(".")) continue
                if (child.isDirectory && child.canRead()) {
                    scanDirForApks(child, depth + 1)
                } else if (child.isFile && child.canRead()) {
                    val lower = child.name.lowercase(Locale.ROOT)
                    if (lower.endsWith(".apk") || lower.endsWith(".apk.part")) {
                        candidateFiles.putIfAbsent(child.absolutePath, child to !lower.endsWith(".part"))
                    }
                }
            }
        }

        scanDirForApks(downloadDir, 0)
        try {
            @Suppress("DEPRECATION")
            val pubDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (pubDownloads != null && pubDownloads.exists()) {
                scanDirForApks(pubDownloads, 0)
            }
        } catch (_: Exception) {
        }

        val items = mutableListOf<ReceivedApkItem>()
        for ((_, pair) in candidateFiles) {
            val (apkFile, shaVerified) = pair
            items.add(inspectApkFile(context, apkFile, shaVerified))
        }

        return items.sortedByDescending { it.lastModifiedMillis }
    }

    fun inspectApkFile(
        context: Context,
        apkFile: File,
        sha256Verified: Boolean = true
    ): ReceivedApkItem {
        val pm = context.packageManager
        val fileLen = if (apkFile.exists()) apkFile.length().coerceAtLeast(0L) else 0L
        val isPartFile = apkFile.name.endsWith(".part", ignoreCase = true)

        if (!apkFile.exists() || !apkFile.canRead() || fileLen <= 0L || isPartFile) {
            val statusLabel = when {
                isPartFile -> "تحميل غير مكتمل (.part) — لا يمكن التثبيت قبل اكتمال النقل"
                fileLen <= 0L -> "ملف فارغ (0 بايت) — غير صالح للتثبيت"
                else -> "ملف غير قابل للقراءة"
            }
            return ReceivedApkItem(
                id = "apk_${apkFile.absolutePath.hashCode()}",
                fileName = apkFile.name,
                appName = apkFile.name.removeSuffix(".part").removeSuffix(".apk"),
                packageName = "حزمة غير مكتملة",
                versionName = "-",
                versionCode = 0L,
                sizeBytes = fileLen,
                lastModifiedMillis = apkFile.lastModified(),
                file = apkFile,
                iconBitmap = null,
                isValidApk = false,
                installStatusLabel = statusLabel,
                sha256Verified = false
            )
        }

        // Check ZIP/APK magic header (PK\x03\x04)
        val hasValidZipHeader = try {
            RandomAccessFile(apkFile, "r").use { raf ->
                if (raf.length() >= 4L) {
                    val b0 = raf.read()
                    val b1 = raf.read()
                    val b2 = raf.read()
                    val b3 = raf.read()
                    b0 == 0x50 && b1 == 0x4B && b2 == 0x03 && b3 == 0x04
                } else false
            }
        } catch (_: Exception) {
            false
        }

        return try {
            val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(apkFile.absolutePath, PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(apkFile.absolutePath, 0)
            }

            if (pkgInfo != null && pkgInfo.applicationInfo != null) {
                val appInfo = pkgInfo.applicationInfo!!
                appInfo.sourceDir = apkFile.absolutePath
                appInfo.publicSourceDir = apkFile.absolutePath

                val appLabel = try {
                    pm.getApplicationLabel(appInfo).toString().takeIf { it.isNotBlank() }
                } catch (_: Exception) {
                    null
                } ?: apkFile.nameWithoutExtension

                val iconBmp = try {
                    InstalledAppsRepository.drawableToImageBitmap(pm.getApplicationIcon(appInfo))
                } catch (_: Throwable) {
                    null
                }

                val verCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    pkgInfo.longVersionCode
                } else {
                    @Suppress("DEPRECATION")
                    pkgInfo.versionCode.toLong()
                }
                val minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) appInfo.minSdkVersion else 21
                val targetSdk = appInfo.targetSdkVersion
                val isCompatible = Build.VERSION.SDK_INT >= minSdk

                ReceivedApkItem(
                    id = "apk_${apkFile.absolutePath.hashCode()}",
                    fileName = apkFile.name,
                    appName = appLabel,
                    packageName = pkgInfo.packageName ?: "unknown.package",
                    versionName = pkgInfo.versionName ?: "1.0",
                    versionCode = verCode,
                    sizeBytes = fileLen,
                    lastModifiedMillis = apkFile.lastModified(),
                    file = apkFile,
                    iconBitmap = iconBmp,
                    isValidApk = isCompatible,
                    minSdkVersion = minSdk,
                    targetSdkVersion = targetSdk,
                    installStatusLabel = if (isCompatible) {
                        if (sha256Verified) "صالح وجاهز للتثبيت (تم التحقق SHA-256)" else "صالح وجاهز للتثبيت"
                    } else {
                        "غير متوافق مع إصدار جهازك (يتطلب Android API $minSdk+)"
                    },
                    sha256Verified = sha256Verified
                )
            } else {
                ReceivedApkItem(
                    id = "apk_${apkFile.absolutePath.hashCode()}",
                    fileName = apkFile.name,
                    appName = apkFile.nameWithoutExtension,
                    packageName = if (hasValidZipHeader) "حزمة APK قياسية" else "ملف APK تالف أو غير صالح",
                    versionName = "1.0",
                    versionCode = 1L,
                    sizeBytes = fileLen,
                    lastModifiedMillis = apkFile.lastModified(),
                    file = apkFile,
                    iconBitmap = null,
                    isValidApk = hasValidZipHeader,
                    installStatusLabel = if (hasValidZipHeader) {
                        "جاهز للتثبيت عبر مثبت النظام"
                    } else {
                        "ملف APK تالف أو غير مكتمل — تعذر قراءة الحزمة"
                    },
                    sha256Verified = sha256Verified
                )
            }
        } catch (t: Throwable) {
            Log.w(LOG_TAG, "Error inspecting APK ${apkFile.name}: ${t.message}")
            ReceivedApkItem(
                id = "apk_${apkFile.absolutePath.hashCode()}",
                fileName = apkFile.name,
                appName = apkFile.nameWithoutExtension,
                packageName = "تعذر تحليل الحزمة",
                versionName = "-",
                versionCode = 0L,
                sizeBytes = fileLen,
                lastModifiedMillis = apkFile.lastModified(),
                file = apkFile,
                iconBitmap = null,
                isValidApk = hasValidZipHeader,
                installStatusLabel = if (hasValidZipHeader) "جاهز للتثبيت" else "ملف APK غير صالح",
                sha256Verified = sha256Verified
            )
        }
    }

    private fun decodeSampledFileBitmap(file: File, reqWidth: Int, reqHeight: Int): ImageBitmap? {
        return try {
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, boundsOpts)
            if (boundsOpts.outWidth <= 0 || boundsOpts.outHeight <= 0) return null
            var inSampleSize = 1
            if (boundsOpts.outHeight > reqHeight || boundsOpts.outWidth > reqWidth) {
                val halfHeight = boundsOpts.outHeight / 2
                val halfWidth = boundsOpts.outWidth / 2
                while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                    inSampleSize *= 2
                }
            }
            val decodeOpts = BitmapFactory.Options().apply {
                this.inSampleSize = max(1, inSampleSize)
                this.inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
            }
            BitmapFactory.decodeFile(file.absolutePath, decodeOpts)?.asImageBitmap()
        } catch (_: OutOfMemoryError) {
            System.gc()
            null
        } catch (_: Throwable) {
            null
        }
    }

    private fun loadMediaThumbnailFast(
        resolver: ContentResolver,
        uri: Uri?,
        mediaId: Long,
        isVideo: Boolean,
        fallbackFile: File? = null,
        cancellationSignal: CancellationSignal? = null
    ): ImageBitmap? {
        try {
            if (uri != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val thumb = runCatching {
                    resolver.loadThumbnail(uri, Size(THUMBNAIL_TARGET_PX, THUMBNAIL_TARGET_PX), cancellationSignal).asImageBitmap()
                }.getOrNull()
                if (thumb != null) return thumb
            }
            if (mediaId >= 0L) {
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = 4
                    inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
                }
                @Suppress("DEPRECATION")
                val bmp = runCatching {
                    if (isVideo) {
                        MediaStore.Video.Thumbnails.getThumbnail(
                            resolver,
                            mediaId,
                            MediaStore.Video.Thumbnails.MINI_KIND,
                            opts
                        )
                    } else {
                        MediaStore.Images.Thumbnails.getThumbnail(
                            resolver,
                            mediaId,
                            MediaStore.Images.Thumbnails.MINI_KIND,
                            opts
                        )
                    }
                }.getOrNull()
                if (bmp != null) return bmp.asImageBitmap()
            }
            if (!isVideo && fallbackFile != null && fallbackFile.exists()) {
                return decodeSampledFileBitmap(fallbackFile, THUMBNAIL_TARGET_PX, THUMBNAIL_TARGET_PX)
            }
        } catch (_: OutOfMemoryError) {
            System.gc()
        } catch (_: Throwable) {
        }
        return null
    }
}
